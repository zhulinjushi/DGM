function [M,K1,K2,F1,F2,F3,Fnx] = eleOperator2(p)
% prepear the reference element Matrix

    [x,z,w]=Gauss_Legendre_Point2(20);
    [x1,w1]=Gauss_Legendre_Point(20);

    Ne=(p+1)*(p+2)/2;
    M=zeros(Ne,Ne);
    K1=zeros(Ne,Ne);
    K2=zeros(Ne,Ne);
    F1=zeros(Ne,Ne);
    F2=zeros(Ne,Ne);
    F3=zeros(Ne,Ne);
    Fnx=cell(3,3);
    for i=1:3
        for j=1:3
            Fnx{i,j}=zeros(Ne,Ne);
        end
    end
    %% M
    for s=0:p
        for t=0:p-s
            a = (p+1)*s-s*(s-1)/2+t+1;  
            r1 = (x+1).*(1-z)/4;
            s1 = (1+z)/2;
            Ps = MonomialPoly(s,r1);
            Pt = MonomialPoly(t,s1);
            for u=0:p
                for v=0:p-u
                    b = (p+1)*u-u*(u-1)/2+v+1;
                    Pu = MonomialPoly(u,r1);
                    Pv = MonomialPoly(v,s1);
                    M(a,b) = w'*(Ps.*Pt.*Pu.*Pv.*(1-z)/8);
                end
            end                                                
        end
    end
    L = (abs(M)<10^-10);
    a = L;
    M(a) = 0;
    %% K
    for s=0:p
        for t=0:p-s
            a = (p+1)*s-s*(s-1)/2+t+1;
            r1 = (x+1).*(1-z)/4;
            s1 = (1+z)/2;
            Ps = MonomialPoly(s,r1);
            Pt = MonomialPolyDiff(t,s1);
            for u=0:p
                for v=0:p-u
                    b = (p+1)*u-u*(u-1)/2+v+1;
                    Pu = MonomialPoly(u,r1);
                    Pv = MonomialPoly(v,s1);
                    K1(a,b) = w'*(Ps.*Pt.*Pu.*Pv.*(1-z)/8);
                end
            end                                                
        end
    end
    L = (abs(K1)<10^-10);
    a = L;
    K1(a) = 0;
    
     for s=0:p
        for t=0:p-s
            a = (p+1)*s-s*(s-1)/2+t+1;
            r1 = (x+1).*(1-z)/4;
            s1 = (1+z)/2;
            Ps = MonomialPolyDiff(s,r1);
            Pt = MonomialPoly(t,s1);
            for u=0:p
                for v=0:p-u
                    b = (p+1)*u-u*(u-1)/2+v+1;
                    Pu = MonomialPoly(u,r1);
                    Pv = MonomialPoly(v,s1);
                    K2(a,b) = w'*(Ps.*Pt.*Pu.*Pv.*(1-z)/8);
                end
            end                                                
        end
    end
    L = (abs(K2)<10^-10);
    a = L;
    K2(a) = 0;
    %% F1
    for s=0:p
        for t=0:p-s
            a = (p+1)*s-s*(s-1)/2+t+1;
            r11 = (x1+1)/2;
            s11 = 0;
            
            Ps = MonomialPoly(s,s11);
            Pt = MonomialPoly(t,r11);
            for u=0:p
                for v=0:p-u
                    b = (p+1)*u-u*(u-1)/2+v+1;
                    Pu = MonomialPoly(u,s11);
                    Pv = MonomialPoly(v,r11);
                    F1(a,b) = w1'*(Ps.*Pt.*Pu.*Pv.*0.5);
                end
            end                                                
        end
    end
    L = (abs(F1)<10^-10);
    a = L;
    F1(a) = 0;
    
    Fnx{1,1} = zeros(Ne,Ne);
    for s=0:p
        for t=0:p-s
            a = (p+1)*s-s*(s-1)/2+t+1;
            r11 = (x1+1)/2;
            s11 = 0;
            r12 = (1-x1)/2;
            s12 = 0;
            
            Ps = MonomialPoly(s,s11);
            Pt = MonomialPoly(t,r11);
            for u=0:p
                for v=0:p-u
                    b = (p+1)*u-u*(u-1)/2+v+1;
                    Pu = MonomialPoly(u,s12);
                    Pv = MonomialPoly(v,r12);
                    Fnx{1,1}(a,b) = w1'*(Ps.*Pt.*Pu.*Pv.*0.5);
                end
            end                                                
        end
    end
    L = (abs(Fnx{1,1})<10^-10);
    a = L;
    Fnx{1,1}(a) = 0;
    
    Fnx{1,2} = zeros(Ne,Ne);
    for s=0:p
        for t=0:p-s
            a = (p+1)*s-s*(s-1)/2+t+1;
            r11 = (x1+1)/2;
            s11 = 0;
            r12 = (x1+1)/2;
            s12 = (1-x1)/2;
            
            Ps = MonomialPoly(s,s11);
            Pt = MonomialPoly(t,r11);
            for u=0:p
                for v=0:p-u
                    b = (p+1)*u-u*(u-1)/2+v+1;
                    Pu = MonomialPoly(u,s12);
                    Pv = MonomialPoly(v,r12);
                    Fnx{1,2}(a,b) = w1'*(Ps.*Pt.*Pu.*Pv.*0.5);
                end
            end                                                
        end
    end
    L = (abs(Fnx{1,2})<10^-10);
    a = L;
    Fnx{1,2}(a) = 0;
    
    Fnx{1,3} = zeros(Ne,Ne);
    for s=0:p
        for t=0:p-s
            a = (p+1)*s-s*(s-1)/2+t+1;
            r11 = (x1+1)/2;
            s11 = 0;
            r12 = 0;
            s12 = (x1+1)/2;
            
            Ps = MonomialPoly(s,s11);
            Pt = MonomialPoly(t,r11);
            for u=0:p
                for v=0:p-u
                    b = (p+1)*u-u*(u-1)/2+v+1;
                    Pu = MonomialPoly(u,s12);
                    Pv = MonomialPoly(v,r12);
                    Fnx{1,3}(a,b) = w1'*(Ps.*Pt.*Pu.*Pv.*0.5);
                end
            end                                                
        end
    end
    L = (abs(Fnx{1,3})<10^-10);
    a = L;
    Fnx{1,3}(a) = 0;
    %% F2
    for s=0:p
        for t=0:p-s
            a = (p+1)*s-s*(s-1)/2+t+1;
            r11 = (1-x1)/2;
            s11 = (1+x1)/2;
            
            Ps = MonomialPoly(s,s11);
            Pt = MonomialPoly(t,r11);
            for u=0:p
                for v=0:p-u
                    b = (p+1)*u-u*(u-1)/2+v+1;
                    Pu = MonomialPoly(u,s11);
                    Pv = MonomialPoly(v,r11);
                    F2(a,b) = w1'*(Ps.*Pt.*Pu.*Pv.*0.5);
                end
            end
        end
    end
    L = (abs(F2)<10^-10);
    a = L;
    F2(a) = 0;
    
    Fnx{2,1} = zeros(Ne,Ne);
    for s=0:p
        for t=0:p-s
            a = (p+1)*s-s*(s-1)/2+t+1;
            r11 = (1-x1)/2;
            s11 = (x1+1)/2;
            r12 = (1-x1)/2;
            s12 = 0;
            
            Ps = MonomialPoly(s,s11);
            Pt = MonomialPoly(t,r11);
            for u=0:p
                for v=0:p-u
                    b = (p+1)*u-u*(u-1)/2+v+1;
                    Pu = MonomialPoly(u,s12);
                    Pv = MonomialPoly(v,r12);
                    Fnx{2,1}(a,b) = w1'*(Ps.*Pt.*Pu.*Pv.*0.5);
                end
            end                                                
        end
    end
    L = (abs(Fnx{2,1})<10^-10);
    a = L;
    Fnx{2,1}(a) = 0;
    
    Fnx{2,2} = zeros(Ne,Ne);
    for s=0:p
        for t=0:p-s
            a = (p+1)*s-s*(s-1)/2+t+1;
            r11 = (1-x1)/2;
            s11 = (1+x1)/2;
            r12 = (x1+1)/2;
            s12 = (1-x1)/2;
            
            Ps = MonomialPoly(s,s11);
            Pt = MonomialPoly(t,r11);
            for u=0:p
                for v=0:p-u
                    b = (p+1)*u-u*(u-1)/2+v+1;
                    Pu = MonomialPoly(u,s12);
                    Pv = MonomialPoly(v,r12);
                    Fnx{2,2}(a,b) = w1'*(Ps.*Pt.*Pu.*Pv.*0.5);
                end
            end                                                
        end
    end
    L = (abs(Fnx{2,2})<10^-10);
    a = L;
    Fnx{2,2}(a) = 0;
    
    Fnx{2,3} = zeros(Ne,Ne);
    for s=0:p
        for t=0:p-s
            a = (p+1)*s-s*(s-1)/2+t+1;
            r11 = (1-x1)/2;
            s11 = (1+x1)/2;
            r12 = 0;
            s12 = (x1+1)/2;
            
            Ps = MonomialPoly(s,s11);
            Pt = MonomialPoly(t,r11);
            for u=0:p
                for v=0:p-u
                    b = (p+1)*u-u*(u-1)/2+v+1;
                    Pu = MonomialPoly(u,s12);
                    Pv = MonomialPoly(v,r12);
                    Fnx{2,3}(a,b) = w1'*(Ps.*Pt.*Pu.*Pv.*0.5);
                end
            end                                                
        end
    end
    L = (abs(Fnx{2,3})<10^-10);
    a = L;
    Fnx{2,3}(a) = 0;
    %% F3
    for s=0:p
        for t=0:p-s
            a = (p+1)*s-s*(s-1)/2+t+1;
            r11 = 0;
            s11 = (1-x1)/2;
            
            Ps = MonomialPoly(s,s11);
            Pt = MonomialPoly(t,r11);
            for u=0:p
                for v=0:p-u
                    b = (p+1)*u-u*(u-1)/2+v+1;
                    Pu = MonomialPoly(u,s11);
                    Pv = MonomialPoly(v,r11);
                    F3(a,b) = w1'*(Ps.*Pt.*Pu.*Pv.*0.5);
                end
            end
        end
    end
    L = (abs(F3)<10^-10);
    a = L;
    F3(a) = 0;
    
    Fnx{3,1} = zeros(Ne,Ne);
    for s=0:p
        for t=0:p-s
            a = (p+1)*s-s*(s-1)/2+t+1;
            r11 = 0;
            s11 = (1-x1)/2;
            r12 = (1-x1)/2;
            s12 = 0;
            
            Ps = MonomialPoly(s,s11);
            Pt = MonomialPoly(t,r11);
            for u=0:p
                for v=0:p-u
                    b = (p+1)*u-u*(u-1)/2+v+1;
                    Pu = MonomialPoly(u,s12);
                    Pv = MonomialPoly(v,r12);
                    Fnx{3,1}(a,b) = w1'*(Ps.*Pt.*Pu.*Pv.*0.5);
                end
            end                                                
        end
    end
    L = (abs(Fnx{3,1})<10^-10);
    a = L;
    Fnx{3,1}(a) = 0;
    
    Fnx{3,2} = zeros(Ne,Ne);
    for s=0:p
        for t=0:p-s
            a = (p+1)*s-s*(s-1)/2+t+1;
            r11 = 0;
            s11 = (1-x1)/2;
            r12 = (x1+1)/2;
            s12 = (1-x1)/2;
            
            Ps = MonomialPoly(s,s11);
            Pt = MonomialPoly(t,r11);
            for u=0:p
                for v=0:p-u
                    b = (p+1)*u-u*(u-1)/2+v+1;
                    Pu = MonomialPoly(u,s12);
                    Pv = MonomialPoly(v,r12);
                    Fnx{3,2}(a,b) = w1'*(Ps.*Pt.*Pu.*Pv.*0.5);
                end
            end                                                
        end
    end
    L = (abs(Fnx{3,2})<10^-10);
    a = L;
    Fnx{3,2}(a) = 0;
    
    Fnx{3,3} = zeros(Ne,Ne);
    for s=0:p
        for t=0:p-s
            a = (p+1)*s-s*(s-1)/2+t+1;
            r11 = 0;
            s11 = (1-x1)/2;
            r12 = 0;
            s12 = (x1+1)/2;
            
            Ps = MonomialPoly(s,s11);
            Pt = MonomialPoly(t,r11);
            for u=0:p
                for v=0:p-u
                    b = (p+1)*u-u*(u-1)/2+v+1;
                    Pu = MonomialPoly(u,s12);
                    Pv = MonomialPoly(v,r12);
                    Fnx{3,3}(a,b) = w1'*(Ps.*Pt.*Pu.*Pv.*0.5);
                end
            end                                                
        end
    end
    L = (abs(Fnx{3,3})<10^-10);
    a = L;
    Fnx{3,3}(a) = 0;
end
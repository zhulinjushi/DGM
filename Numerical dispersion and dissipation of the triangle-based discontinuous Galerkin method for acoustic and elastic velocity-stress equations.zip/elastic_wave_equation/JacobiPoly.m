function out=JacobiPoly(n,alpha,belta,x)
% compute value of Jacobi polynominal at each x.

[a,b]=size(x);
out = ones(a,b);

if (n==0)
    return;
end
out1=0.5*(2*(alpha+1)+(alpha+belta+2)*(x-1));
if (n==1)
    out =out1;
    return;
end
if (n>1)
    for i=2:n
        c1=2*i*(i+alpha+belta)*(2*(i-1)+alpha+belta);
        c2=(2*i-1+alpha+belta)*(alpha*alpha-belta*belta);
        c3=(2*i-2+alpha+belta)*(2*i-1+alpha+belta)*(2*i+alpha+belta);
        c4=-2.0*(i-1+alpha)*(i-1+belta)*(2*i+alpha+belta);
        temp = ((c2+c3*x).*out1+c4*out)/c1;
        
        out=out1;
        out1=temp;
        temp=out;
    end
    out=out1;
    return;
end

function [dispersion,dissipation] = Flux_for_acoustic_equation(vp,rho,p,minedge1,sp,theta,gama,flux,method)
%% This code is developed by Jiandong Huang for the dispersion and dissipation analysis for the triangle-based DGM. 
%% It corresponds to the example in section 3.5 of the manuscript "Numerical dispersion and dissipation of 
%% the triangle-based discontinuous Galerkin method for acoustic and elastic velocity-stress equations" 
%% (Authors: Jiandong Huang, Tianyue Hu, Yandong Li, Jianyong Song, Shanglin Liang). 
%% 2020
%% acoustic wave equation for flux
mm = ceil(2*pi/gama);
dispersion = zeros(1,length(0:mm));
dissipation = zeros(1,length(0:mm));
for k = 0:mm
    [minedisvp,dissp] = AcousticGridDispersion(vp,rho,p,sp,theta,k*gama,minedge1,flux,method);
    dispersion(k+1) = minedisvp;
    dissipation(k+1) = dissp;
end
end












function [dispersion,dissipation] = Basis_for_acoustic_equation(vp,rho,p,minedge1,maxsp,dsp,theta,gama,flux,method)
%% This code is developed by Jiandong Huang for the dispersion and dissipation analysis for the triangle-based DGM. 
%% It corresponds to the example in section 3.5 of the manuscript "Numerical dispersion and dissipation of 
%% the triangle-based discontinuous Galerkin method for acoustic and elastic velocity-stress equations" 
%% (Authors: Jiandong Huang, Tianyue Hu, Yandong Li, Jianyong Song, Shanglin Liang). 
%% 2020
%% acoustic wave equation for basis function
maxminedge = ceil(maxsp/dsp);
dispersion = zeros(1,length(1:maxminedge));
dissipation = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    sp = k*dsp;
    [minedisvp,dissp] = AcousticGridDispersion(vp,rho,p,sp,theta,gama,minedge1,flux,method);
    dispersion(k) = minedisvp;
    dissipation(k) = dissp;
end
end
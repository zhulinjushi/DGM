function out = LegendrePoly(n,x)
% compute value of Jacobi polynominal at each x.
[a,b]=size(x);
out = ones(a,b);

if (n==0)
    return;
end
out1=0.5*(2*(1)+(2)*(x-1));
if (n==1)
    out =out1;
    return;
end
if (n>1)
    for i=2:n
        c1=2*i*(i)*(2*(i-1));
        c2=(2*i-1)*(0);
        c3=(2*i-2)*(2*i-1)*(2*i);
        c4=-2.0*(i-1)*(i-1)*(2*i);
        temp = ((c2+c3*x).*out1+c4*out)/c1;
        
        out=out1;
        out1=temp;
        temp=out;
    end
    out=out1;
    return;
end

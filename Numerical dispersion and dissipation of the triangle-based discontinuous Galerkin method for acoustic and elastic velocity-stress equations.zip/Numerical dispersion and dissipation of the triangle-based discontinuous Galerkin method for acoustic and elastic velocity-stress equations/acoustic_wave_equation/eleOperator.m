function [M,K1,K2,F1,F2,F3,Fnx]=eleOperator(p)
% prepear the reference element Matrix

[x,w]=Gauss_Legendre_Point(20);

Ne=(p+1)*(p+2)/2;
M=zeros(Ne,Ne);
K1=zeros(Ne,Ne);
K2=zeros(Ne,Ne);
F1=zeros(Ne,Ne);
F2=zeros(Ne,Ne);
F3=zeros(Ne,Ne);
Fnx=cell(3,3);
for i=1:3
    for j=1:3
        Fnx{i,j}=zeros(Ne,Ne);
    end
end
%% M
for s=0:p
    for t=0:p-s
        a=matsub(p,t,s);
        Ps=JacobiPoly(s,0,0,x);Pt=JacobiPoly(t,2*s+1,0,x);
        for u=0:p
            for v=0:p-u
                b=matsub(p,v,u);
                Pu=JacobiPoly(u,0,0,x);Pv=JacobiPoly(v,2*u+1,0,x);
                M(a,b)=(w'*(Ps.*Pu))*(w'*(Pt.*Pv.*((1-x)/2).^(s+u).*(1-x)/8));
            end
        end
    end
end
L=(abs(M)<10^-10);
a=find(L);
M(a)=0;

%% K
for s=0:p
    for t=0:p-s
        a=matsub(p,t,s);
        if s==0
            Ps=0;
        else
            Ps=(s+1)/2*JacobiPoly(s-1,1,1,x);
        end
        Pt=JacobiPoly(t,2*s+1,0,x);
        for u=0:p
            for v=0:p-u
                b=matsub(p,v,u);
                Pu=JacobiPoly(u,0,0,x);Pv=JacobiPoly(v,2*u+1,0,x);
                K1(a,b)=0.5*(w'*(Ps.*Pu))*(w'*(Pt.*Pv.*((1-x)/2).^(s+u)));
            end
        end
    end
end
L=(abs(K1)<10^-10);
a=find(L);
K1(a)=0;

for s=0:p
    for t=0:p-s
        a=matsub(p,t,s);
        Ps=JacobiPoly(s,0,0,x);
        if s==0
            Ps_1=0;            
        else
            Ps_1=JacobiPoly(s-1,1,1,x);
        end
        Pt=JacobiPoly(t,2*s+1,0,x);
        if t==0
            Pt_1=0;
        else
            Pt_1=JacobiPoly(t-1,2*s+2,1,x);
        end
        
        for u=0:p
            for v=0:p-u
                b=matsub(p,v,u);
                Pu=JacobiPoly(u,0,0,x);Pv=JacobiPoly(v,2*u+1,0,x);
                K2(a,b)=w'*((1+s)/2*Ps_1.*(x+1)/4.*Pu)...
                    *(w'*(Pt.*Pv.*((1-x)/2).^(u+s)))...
                    +w'*(Ps.*Pu)...
                    *(w'*(   (1-x)/4.*Pv.*((1-x)/2).^u.*(...
                    (t+2*s+2)/2*Pt_1.*(0.5-0.5*x).^s...
                    - 0.5*Pt*s.*(0.5-0.5*x).^(s-1) )   ));
            end
        end
    end
end
L=(abs(K2)<10^-10);
a=find(L);
K2(a)=0;

%% F
for s=0:p
    for t=0:p-s
        a=matsub(p,t,s);
        Ps=JacobiPoly(s,0,0,x);Pt=JacobiPoly(t,2*s+1,0,-1);
        for u=0:p
            for v=0:p-u
                b=matsub(p,v,u);
                Pu=JacobiPoly(u,0,0,x);Pv=JacobiPoly(v,2*u+1,0,-1);
                F1(a,b)=0.5*w'*(Ps.*Pt.*Pu.*Pv);
            end
        end
    end
end
L=(abs(F1)<10^-10);
a=find(L);
F1(a)=0;

Fnx{1,1}=zeros(Ne,Ne);%
for s=0:p
    for t=0:p-s
        a=matsub(p,t,s);
        Ps=JacobiPoly(s,0,0,x);Pt=JacobiPoly(t,2*s+1,0,-1);
        for u=0:p
            for v=0:p-u
                b=matsub(p,v,u);
                Pu=JacobiPoly(u,0,0,-x);Pv=JacobiPoly(v,2*u+1,0,-1);
                Fnx{1,1}(a,b)=0.5*w'*(Ps.*Pt.*Pu.*Pv);
            end
        end
    end
end
L=(abs(Fnx{1,1})<10^-10);
a=find(L);
Fnx{1,1}(a)=0;

Fnx{1,2}=zeros(Ne,Ne);
for s=0:p
    for t=0:p-s
        a=matsub(p,t,s);
        Ps=JacobiPoly(s,0,0,x);Pt=JacobiPoly(t,2*s+1,0,-1);
        for u=0:p
            for v=0:p-u
                b=matsub(p,v,u);
                Pu=JacobiPoly(u,0,0,1);Pv=JacobiPoly(v,2*u+1,0,-x);
                Fnx{1,2}(a,b)=0.5*w'*(Ps.*Pt.*Pu.*Pv.*((1+x)/2).^(u));
            end
        end
    end
end
L=(abs(Fnx{1,2})<10^-10);
a=find(L);
Fnx{1,2}(a)=0;

Fnx{1,3}=zeros(Ne,Ne);
for s=0:p
    for t=0:p-s
        a=matsub(p,t,s);
        Ps=JacobiPoly(s,0,0,x);Pt=JacobiPoly(t,2*s+1,0,-1);
        for u=0:p
            for v=0:p-u
                b=matsub(p,v,u);
                Pu=JacobiPoly(u,0,0,-1);Pv=JacobiPoly(v,2*u+1,0,x);
                Fnx{1,3}(a,b)=0.5*w'*(Ps.*Pt.*Pu.*Pv.*((1-x)/2).^(u));
            end
        end
    end
end
L=(abs(Fnx{1,3})<10^-10);
a=find(L);
Fnx{1,3}(a)=0;

for s=0:p
    for t=0:p-s
        a=matsub(p,t,s);
        Ps=JacobiPoly(s,0,0,1);Pt=JacobiPoly(t,2*s+1,0,-x);
        for u=0:p
            for v=0:p-u
                b=matsub(p,v,u);
                Pu=JacobiPoly(u,0,0,1);Pv=JacobiPoly(v,2*u+1,0,-x);
                F2(a,b)=0.5*w'*(Ps.*Pt.*Pu.*Pv.*((1+x)/2).^(s+u));
            end
        end
    end
end
L=(abs(F2)<10^-10);
a=find(L);
F2(a)=0;

Fnx{2,1}=zeros(Ne,Ne);
for s=0:p
    for t=0:p-s
        a=matsub(p,t,s);
        Ps=JacobiPoly(s,0,0,1);Pt=JacobiPoly(t,2*s+1,0,-x);
        for u=0:p
            for v=0:p-u
                b=matsub(p,v,u);
                Pu=JacobiPoly(u,0,0,x);Pv=JacobiPoly(v,2*u+1,0,-1);
                Fnx{2,1}(a,b)=0.5*w'*(Ps.*Pt.*Pu.*Pv.*((1+x)/2).^(s));
            end
        end
    end
end
L=(abs(Fnx{2,1})<10^-10);
a=find(L);
Fnx{2,1}(a)=0;

Fnx{2,2}=zeros(Ne,Ne);%��
for s=0:p
    for t=0:p-s
        a=matsub(p,t,s);
        Ps=JacobiPoly(s,0,0,1);Pt=JacobiPoly(t,2*s+1,0,-x);
        for u=0:p
            for v=0:p-u
                b=matsub(p,v,u);
                Pu=JacobiPoly(u,0,0,1);Pv=JacobiPoly(v,2*u+1,0,x);
                Fnx{2,2}(a,b)=0.5*w'*(Ps.*Pt.*Pu.*Pv.*((1+x)/2).^(s).*((1-x)/2).^(u));
            end
        end
    end
end
L=(abs(Fnx{2,2})<10^-10);
a=find(L);
Fnx{2,2}(a)=0;

Fnx{2,3}=zeros(Ne,Ne);%
for s=0:p
    for t=0:p-s
        a=matsub(p,t,s);
        Ps=JacobiPoly(s,0,0,1);Pt=JacobiPoly(t,2*s+1,0,-x);
        for u=0:p
            for v=0:p-u
                b=matsub(p,v,u);
                Pu=JacobiPoly(u,0,0,-1);Pv=JacobiPoly(v,2*u+1,0,-x);
                Fnx{2,3}(a,b)=0.5*w'*(Ps.*Pt.*Pu.*Pv.*((1+x)/2).^(s+u));
            end
        end
    end
end
L=(abs(Fnx{2,3})<10^-10);
a=find(L);
Fnx{2,3}(a)=0;

for s=0:p
    for t=0:p-s
        a=matsub(p,t,s);
        Ps=JacobiPoly(s,0,0,-1);Pt=JacobiPoly(t,2*s+1,0,x);
        for u=0:p
            for v=0:p-u
                b=matsub(p,v,u);
                Pu=JacobiPoly(u,0,0,-1);Pv=JacobiPoly(v,2*u+1,0,x);
                F3(a,b)=0.5*w'*(Ps.*Pt.*Pu.*Pv.*((1-x)/2).^(s+u));
            end
        end
    end
end
L=(abs(F3)<10^-10);
a=find(L);
F3(a)=0;

Fnx{3,1}=zeros(Ne,Ne);
for s=0:p
    for t=0:p-s
        a=matsub(p,t,s);
        Ps=JacobiPoly(s,0,0,-1);Pt=JacobiPoly(t,2*s+1,0,x);
        for u=0:p
            for v=0:p-u
                b=matsub(p,v,u);
                Pu=JacobiPoly(u,0,0,x);Pv=JacobiPoly(v,2*u+1,0,-1);
                Fnx{3,1}(a,b)=0.5*w'*(Ps.*Pt.*Pu.*Pv.*((1-x)/2).^(s));
            end
        end
    end
end
L=(abs(Fnx{3,1})<10^-10);
a=find(L);
Fnx{3,1}(a)=0;

Fnx{3,2}=zeros(Ne,Ne);%
for s=0:p
    for t=0:p-s
        a=matsub(p,t,s);
        Ps=JacobiPoly(s,0,0,-1);Pt=JacobiPoly(t,2*s+1,0,x);
        for u=0:p
            for v=0:p-u
                b=matsub(p,v,u);
                Pu=JacobiPoly(u,0,0,1);Pv=JacobiPoly(v,2*u+1,0,x);
                Fnx{3,2}(a,b)=0.5*w'*(Ps.*Pt.*Pu.*Pv.*((1-x)/2).^(s+u));
            end
        end
    end
end
L=(abs(Fnx{3,2})<10^-10);
a=find(L);
Fnx{3,2}(a)=0;

Fnx{3,3}=zeros(Ne,Ne);%
for s=0:p
    for t=0:p-s
        a=matsub(p,t,s);
        Ps=JacobiPoly(s,0,0,-1);Pt=JacobiPoly(t,2*s+1,0,x);
        for u=0:p
            for v=0:p-u
                b=matsub(p,v,u);
                Pu=JacobiPoly(u,0,0,-1);Pv=JacobiPoly(v,2*u+1,0,-x);
                Fnx{3,3}(a,b)=0.5*w'*(Ps.*Pt.*Pu.*Pv.*((1-x)/2).^(s).*((1+x)/2).^(u));
            end
        end
    end
end
L=(abs(Fnx{3,3})<10^-10);
a=find(L);
Fnx{3,3}(a)=0;

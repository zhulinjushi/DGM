function [flowin,flowout] = AcousticLaxFriedrich(nx,nz,A,B,vmax,tao)
    %% tao =1 laxfriedrich flux or ta0 =0 center flux
    I = eye(3);
    flowin = (nx*A+nz*B+tao*vmax*I)/2;
    flowout = (nx*A+nz*B-tao*vmax*I)/2;
end
function [vpdispersion,vpdissipation,vsdispersion,vsdissipation] = Flux_for_elastic_equation(vp,vs,rho,p,minedge1,sp,theta,gama,flux,method)
%% This code is developed by Jiandong Huang for the dispersion and dissipation analysis for the triangle-based DGM. 
%% It corresponds to the example in section 3.5 of the manuscript "Numerical dispersion and dissipation of 
%% the triangle-based discontinuous Galerkin method for acoustic and elastic velocity-stress equations" 
%% (Authors: Jiandong Huang, Tianyue Hu, Yandong Li, Jianyong Song, Shanglin Liang). 
%% 2020
%% elastic wave equation for flux
mm = ceil(2*pi/gama);
vpdispersion = zeros(1,length(0:mm));
vpdissipation = zeros(1,length(0:mm));
vsdispersion = zeros(1,length(0:mm));
vsdissipation = zeros(1,length(0:mm));
for k = 0:mm
    [minedisvp,dissp,minedisvs,disss] = GridDispersion(vp,vs,rho,p,sp,theta,k*gama,minedge1,flux,method);
    vpdispersion(k+1) = minedisvp;
    vpdissipation(k+1) = dissp;
    vsdispersion(k+1) = minedisvs;
    vsdissipation(k+1) = disss;
end
end


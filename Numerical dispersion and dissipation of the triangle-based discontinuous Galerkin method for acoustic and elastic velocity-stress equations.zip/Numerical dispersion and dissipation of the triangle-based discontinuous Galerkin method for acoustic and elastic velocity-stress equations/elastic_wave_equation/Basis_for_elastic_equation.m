function [vpdispersion,vpdissipation,vsdispersion,vsdissipation] = Basis_for_elastic_equation(vp,vs,rho,p,minedge1,spmax,dsp,theta,gama,flux,method)
%% This code is developed by Jiandong Huang for the dispersion and dissipation analysis for the triangle-based DGM. 
%% It corresponds to the example in section 3.5 of the manuscript "Numerical dispersion and dissipation of 
%% the triangle-based discontinuous Galerkin method for acoustic and elastic velocity-stress equations" 
%% (Authors: Jiandong Huang, Tianyue Hu, Yandong Li, Jianyong Song, Shanglin Liang). 
%% 2020
%% elastic wave equation for basis function
maxminedge = ceil(spmax/dsp);
vpdispersion = zeros(1,length(1:maxminedge));
vpdissipation = zeros(1,length(1:maxminedge));
vsdispersion = zeros(1,length(1:maxminedge));
vsdissipation = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    sp = k*dsp;
    [minedisvp,dissp,minedisvs,disss] = GridDispersion(vp,vs,rho,p,sp,theta,gama,minedge1,flux,method);
    vpdispersion(k) = minedisvp;
    vpdissipation(k) = dissp;
    vsdispersion(k) = minedisvs;
    vsdissipation(k) = disss;
end
end
function [flowin,flowout] = Godunov(nx,nz,vp,vs,rho)
%% Godunov
%%
% T = zeros(5,5);
T(1,1) = nx*nx;
T(1,2) = nz*nz;
T(1,3) = -2*nx*nz;
T(2,1) = nz*nz;
T(2,2) = nx*nx;
T(2,3) = 2*nx*nz;
T(3,1) = nx*nz;
T(3,2) = -nx*nz;
T(3,3) = nx*nx-nz*nz;
T(4,4) = nx;
T(4,5) = -nz;
T(5,4) = nz;
T(5,5) = nx;
%%
% Tinv = zeros(5,5);
Tinv(1,1) = nx*nx;
Tinv(1,2) = nz*nz;
Tinv(1,3) = 2*nx*nz;
Tinv(2,1) = nz*nz;
Tinv(2,2) = nx*nx;
Tinv(2,3) = -2*nx*nz;
Tinv(3,1) = -nx*nz;
Tinv(3,2) = nx*nz;
Tinv(3,3) = nx*nx-nz*nz;
Tinv(4,4) = nx;
Tinv(4,5) = nz;
Tinv(5,4) = -nz;
Tinv(5,5) = nx;
%%
mu=rho*vs^2;
lambda=rho*vp^2-2*mu;

% APA = zeros(5,5);
APA(1,1) = vp;
APA(1,4) = -(lambda+2*mu);
APA(2,1) = lambda*vp/(lambda+2*mu);
APA(2,4) = -lambda;
APA(3,3) = vs;
APA(3,5) = -mu;
APA(4,1) = -1/rho;
APA(4,4) = vp;
APA(5,3) = -1/rho;
APA(5,5) = vs;

% AMA= zeros(5,5);
AMA(1,1) = -vp;
AMA(1,4) = -(lambda+2*mu);
AMA(2,1) = -lambda*vp/(lambda+2*mu);
AMA(2,4) = -lambda;
AMA(3,3) = -vs;
AMA(3,5) = -mu;
AMA(4,1) = -1/rho;
AMA(4,4) = -vp;
AMA(5,3) = -1/rho;
AMA(5,5) = -vs;
%%
flowin = 0.5*T*APA*Tinv;
flowout = 0.5*T*AMA*Tinv;
end
function out = LegendrePolyDiff(n,x)
% compute value of Jacobi polynominal at each x.
[a,b]=size(x);
out = zeros(a,b);

if (n==0)
    return;
end
out1=1;
if (n==1)
    out =out1;
    return;
end
p1 = 1;
p2 = x;
p1d = 0;
p2d = 1;
p3d = 1;
if (n>1)
    for i=1:n-1
        p3 = ((2.*i+1).*x.*p2-i.*p1)./(i+1);
        p3d = ((2.*i+1).*p2+(2.*i+1).*x.*p2d-i*p1d)./(i+1);
        p1 = p2;
        p2 = p3;
        p1d = p2d;
        p2d = p3d;
    end
    out=p3d;
    return;
end

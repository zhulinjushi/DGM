clc;clear;close all;
%% order
vp = 2100; 
rho = 2000;
f = 30;
theta = pi/2;
p = 2;
ktao = 1/p;
maxminedge = ceil(vp/f/2);
bolminp = vp/f;
vpsamplepoint =zeros(1,maxminedge);
for k = 1:maxminedge
    vpsamplepoint(k) = k/bolminp;
end
%%
gama = pi/12;

e1p = zeros(1,length(1:maxminedge));
e1s = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp] = AcousticGridDispersion(vp,rho,f,p,ktao,theta,gama,k,'LaxFredrichsFlux','semi');
    e1p(k) = minedisvp;
    e1s(k) = dissp;
end

e2p = zeros(1,length(1:maxminedge));
e2s = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp] = AcousticGridDispersion2(vp,rho,f,p,ktao,theta,gama,k,'LaxFredrichsFlux','semi');
    e2p(k) = minedisvp;
    e2s(k) = dissp;
end

e3p = zeros(1,length(1:maxminedge));
e3s = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp] = AcousticGridDispersion3(vp,rho,f,p,ktao,theta,gama,k,'LaxFredrichsFlux','semi');
    e3p(k) = minedisvp;
    e3s(k) = dissp;
end

gama = pi/3;

e4p = zeros(1,length(1:maxminedge));
e4s = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp] = AcousticGridDispersion(vp,rho,f,p,ktao,theta,gama,k,'LaxFredrichsFlux','semi');
    e4p(k) = minedisvp;
    e4s(k) = dissp;
end

e5p = zeros(1,length(1:maxminedge));
e5s = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp] = AcousticGridDispersion2(vp,rho,f,p,ktao,theta,gama,k,'LaxFredrichsFlux','semi');
    e5p(k) = minedisvp;
    e5s(k) = dissp;
end

e6p = zeros(1,length(1:maxminedge));
e6s = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp] = AcousticGridDispersion3(vp,rho,f,p,ktao,theta,gama,k,'LaxFredrichsFlux','semi');
    e6p(k) = minedisvp;
    e6s(k) = dissp;
end

gama = pi/2;

e7p = zeros(1,length(1:maxminedge));
e7s = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp] = AcousticGridDispersion(vp,rho,f,p,ktao,theta,gama,k,'LaxFredrichsFlux','semi');
    e7p(k) = minedisvp;
    e7s(k) = dissp;
end

e8p = zeros(1,length(1:maxminedge));
e8s = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp] = AcousticGridDispersion2(vp,rho,f,p,ktao,theta,gama,k,'LaxFredrichsFlux','semi');
    e8p(k) = minedisvp;
    e8s(k) = dissp;
end

e9p = zeros(1,length(1:maxminedge));
e9s = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp] = AcousticGridDispersion3(vp,rho,f,p,ktao,theta,gama,k,'LaxFredrichsFlux','semi');
    e9p(k) = minedisvp;
    e9s(k) = dissp;
end

gama = 3*pi/4;

e10p = zeros(1,length(1:maxminedge));
e10s = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
%     [minedisvp,dissp] = AcousticGridDispersion1(vp,rho,f,p,ktao,tau,theta,gama,k,'3TVDRK');
    [minedisvp,dissp] = AcousticGridDispersion(vp,rho,f,p,ktao,theta,gama,k,'LaxFredrichsFlux','semi');
    e10p(k) = minedisvp;
    e10s(k) = dissp;
end

e11p = zeros(1,length(1:maxminedge));
e11s = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp] = AcousticGridDispersion2(vp,rho,f,p,ktao,theta,gama,k,'LaxFredrichsFlux','semi');
    e11p(k) = minedisvp;
    e11s(k) = dissp;
end

e12p = zeros(1,length(1:maxminedge));
e12s = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp] = AcousticGridDispersion3(vp,rho,f,p,ktao,theta,gama,k,'LaxFredrichsFlux','semi');
    e12p(k) = minedisvp;
    e12s(k) = dissp;
end
%% 
figure;
set(gcf,'unit','centimeters','position',[20 1 15 15]); 
% polarplot(angle,e1p,'--b','LineWidth',2.5); 

plot(vpsamplepoint(1:3:end),e1p(1:3:end),'^','LineWidth',2,'Color',[1 0 0]); 
hold on;
plot(vpsamplepoint(2:3:end),e2p(2:3:end),'s','LineWidth',2,'Color',[1 0 0]); 
hold on;
plot(vpsamplepoint(3:3:end),e3p(3:3:end),'*','LineWidth',2,'Color',[1 0 0]); 
hold on;

plot(vpsamplepoint(1:3:end),e4p(1:3:end),'^','LineWidth',2,'Color',[0.13333 0.5451 0.13333]); 
hold on;
plot(vpsamplepoint(2:3:end),e5p(2:3:end),'s','LineWidth',2,'Color',[0.13333 0.5451 0.13333]); 
hold on;
plot(vpsamplepoint(3:3:end),e6p(3:3:end),'*','LineWidth',2,'Color',[0.13333 0.5451 0.13333]); 
hold on;

plot(vpsamplepoint(1:3:end),e7p(1:3:end),'^','LineWidth',2,'Color',[0.69804 0.13333 0.13333]); 
hold on;
plot(vpsamplepoint(2:3:end),e8p(2:3:end),'s','LineWidth',2,'Color',[0.69804 0.13333 0.13333]); 
hold on;
plot(vpsamplepoint(3:3:end),e9p(3:3:end),'*','LineWidth',2,'Color',[0.69804 0.13333 0.13333]); 
hold on;

plot(vpsamplepoint(1:3:end),e10p(1:3:end),'^','LineWidth',2,'Color',[0.6 0.19608 0.8]); 
hold on;
plot(vpsamplepoint(2:3:end),e11p(2:3:end),'s','LineWidth',2,'Color',[0.6 0.19608 0.8]); 
hold on;
plot(vpsamplepoint(3:3:end),e12p(3:3:end),'*','LineWidth',2,'Color',[0.6 0.19608 0.8]); 
hold on;


plot(vpsamplepoint,e1p,'-','LineWidth',1,'Color',[0 0 0]); 
hold on;
plot(vpsamplepoint,e4p,'-','LineWidth',1,'Color',[0 0 0]); 
hold on;
plot(vpsamplepoint,e7p,'-','LineWidth',1,'Color',[0 0 0]); 
hold on;
plot(vpsamplepoint,e10p,'-','LineWidth',1,'Color',[0 0 0]); 
hold on;

axis([0,0.30,0.999,1.05]);
xlabel('\delta','FontSize',13);
ylabel('R ','FontSize',13);
set(gca,'XTick',0:0.05:0.3);
set(gca,'XTicklabel',{'0','0.05','0.1','0.15','0.2','0.25','0.3'});
set(gca,'YTick',1:0.01:1.05);
set(gca,'YTicklabel',{'1','1.01','1.02','1.03','1.04','1.05'});
set(gca,'FontSize',15);
set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
set(gca,'Linewidth',1.5,'GridAlpha',1);
legend('K D  \gamma = \pi/12','Monomial \gamma = \pi/12','Legendre  \gamma = \pi/12',...
       'K D  \gamma = \pi/3','Monomial  \gamma = \pi/3','Legendre   \gamma = \pi/3',...
       'K D  \gamma = \pi/2','Monomial  \gamma = \pi/2','Legendre  \gamma = \pi/2',...
       'K D  \gamma = 3\pi/4','Monomial \gamma = 3\pi/4','Legendre  \gamma = 3\pi/4','Location','northwest');

   %% 
figure;
set(gcf,'unit','centimeters','position',[20 1 15 15]); 
% polarplot(angle,e1p,'--b','LineWidth',2.5); 

plot(vpsamplepoint(1:3:end),e1s(1:3:end),'^','LineWidth',2,'Color',[1 0 0]); 
hold on;
plot(vpsamplepoint(2:3:end),e2s(2:3:end),'s','LineWidth',2,'Color',[1 0 0]); 
hold on;
plot(vpsamplepoint(3:3:end),e3s(3:3:end),'*','LineWidth',2,'Color',[1 0 0]); 
hold on;

plot(vpsamplepoint(1:3:end),e4s(1:3:end),'^','LineWidth',2,'Color',[0.13333 0.5451 0.13333]); 
hold on;
plot(vpsamplepoint(2:3:end),e5s(2:3:end),'s','LineWidth',2,'Color',[0.13333 0.5451 0.13333]); 
hold on;
plot(vpsamplepoint(3:3:end),e6s(3:3:end),'*','LineWidth',2,'Color',[0.13333 0.5451 0.13333]); 
hold on;

plot(vpsamplepoint(1:3:end),e7s(1:3:end),'^','LineWidth',2,'Color',[0.69804 0.13333 0.13333]); 
hold on;
plot(vpsamplepoint(2:3:end),e8s(2:3:end),'s','LineWidth',2,'Color',[0.69804 0.13333 0.13333]); 
hold on;
plot(vpsamplepoint(3:3:end),e9s(3:3:end),'*','LineWidth',2,'Color',[0.69804 0.13333 0.13333]); 
hold on;

plot(vpsamplepoint(1:3:end),e10s(1:3:end),'^','LineWidth',2,'Color',[0.6 0.19608 0.8]); 
hold on;
plot(vpsamplepoint(2:3:end),e11s(2:3:end),'s','LineWidth',2,'Color',[0.6 0.19608 0.8]); 
hold on;
plot(vpsamplepoint(3:3:end),e12s(3:3:end),'*','LineWidth',2,'Color',[0.6 0.19608 0.8]); 
hold on;

plot(vpsamplepoint,e1s,'-','LineWidth',1,'Color',[0 0 0]); 
hold on;
plot(vpsamplepoint,e4s,'-','LineWidth',1,'Color',[0 0 0]); 
hold on;
plot(vpsamplepoint,e7s,'-','LineWidth',1,'Color',[0 0 0]); 
hold on;
plot(vpsamplepoint,e10s,'-','LineWidth',1,'Color',[0 0 0]); 
hold on;

axis([0,0.30,0.985,1.001]);
xlabel('\delta','FontSize',13);
ylabel('S','FontSize',13);
set(gca,'XTick',0:0.05:0.3);
set(gca,'XTicklabel',{'0','0.05','0.1','0.15','0.2','0.25','0.3'});
set(gca,'YTick',0.985:0.003:1.001);
set(gca,'YTicklabel',{'0.985','0.988','0.991','0.994','0.997','1'});
set(gca,'FontSize',15);
set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
set(gca,'Linewidth',1.5,'GridAlpha',1);
legend('K D  \gamma = \pi/12','Monomial \gamma = \pi/12','Legendre  \gamma = \pi/12',...
       'K D  \gamma = \pi/3','Monomial  \gamma = \pi/3','Legendre   \gamma = \pi/3',...
       'K D  \gamma = \pi/2','Monomial  \gamma = \pi/2','Legendre  \gamma = \pi/2',...
       'K D  \gamma = 3\pi/4','Monomial \gamma = 3\pi/4','Legendre  \gamma = 3\pi/4','Location','southwest');

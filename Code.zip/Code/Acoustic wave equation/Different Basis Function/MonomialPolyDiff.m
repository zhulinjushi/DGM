function [out] = MonomialPolyDiff(n,x)
%% compute value of Monominal polynominal at each x.
    [a,b]=size(x);
    out = zeros(a,b);
    if (n==0)
        return;
    end
    out1 = ones(a,b);
    if (n==1)
        out =out1;
        return;
    end

    if (n>1)
        for i=2:n            
            out1 = x.*out1;
        end
        out = n.*out1;
        return;
    end
end
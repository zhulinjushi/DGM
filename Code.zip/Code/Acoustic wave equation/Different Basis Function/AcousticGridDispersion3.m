%% GridDispersion
function [minedisvp,dissp] = AcousticGridDispersion3(vp,rho,fpeak,p,ktao,theta,gama,minedge,flux,method)
%%
%% vp �ٶ�,rho �ܶ�,fpeak ��Ƶ,p ����,tau ,theta �����ζ���,gama ��������,minedge ��̱߳�,method ʱ����ɢ��ʽ
%% Tensor product form
%     fmax=2*fpeak;
    bolminp = vp/fpeak;  %����

    N =(p+1)*(p+2)/2;

    sp = minedge/bolminp/ktao;

%     A = 0.5*minedge^2*sin(theta);
%     J = 2*A;

%     O = zeros(N,N);
%     c0 = -1/rho;
%     c1 = -(lambda+2*mu);
%     c2 = -lambda;
%     c3 = -mu;
    %%
    [M,K1,K2,F1,F2,F3,Fnx]=eleOperator3(p);

    FF1=Fnx{1,1};FF2=Fnx{2,2};FF3=Fnx{3,3};
%% �ſ˱Ⱦ���
 %% Ӧ��-�ٶ���ʽ
%     kmodul = rho*vp*vp;
%     JA = zeros(3,3); 
%     JB = zeros(3,3);
%     
%     JA(1,2) = -  kmodul;
%     JA(2,1) = -1/rho;
%     
%     JB(1,3) = -  kmodul;
%     JB(3,1) = -1/rho;
    %% ��������
    temp = rho;
    kmodul = vp*vp;
    JA = zeros(3,3); 
    JB = zeros(3,3);
    
    JA(1,2) = -  kmodul;
    JA(2,1) = -1;
    
    JB(1,3) = -  kmodul;
    JB(3,1) = -1;
    
%%
%%
    O = zeros(N,N);
    Init = eye(3);
    OO = kron(Init,O);
    II = kron(Init,M);
  %% P wave
    phaseT = exp(1i*2*pi*sp*cos(gama)*cos(theta))*exp(1i*2*pi*sp*sin(gama)*sin(theta));
    phaseB = exp(-1i*2*pi*sp*cos(gama)*cos(theta))*exp(-1i*2*pi*sp*sin(gama)*sin(theta));
    phaseL = exp(-1i*2*pi*sp*cos(gama));
    phaseR = exp(1i*2*pi*sp*cos(gama));  
        
    %%
    %��һ����Ԫ
    kk1 = JA*(1/minedge)+JB*(-cos(theta)/(minedge*sin(theta)));
    kk2 = JA*(0)+JB*(1/(minedge*sin(theta)));
    kk = kron(kk1,K1)+kron(kk2,K2);

%     [flowin1,flowout1] = AcousticLaxFriedrich(0,-1,JA,JB,vp,tau);
%     [flowin2,flowout2] = AcousticLaxFriedrich(cos(theta/2),sin(theta/2),JA,JB,vp,tau);
%     [flowin3,flowout3] = AcousticLaxFriedrich(-sin(theta),cos(theta),JA,JB,vp,tau);
    if(strcmp(flux,'LaxFredrichsFlux'))
        tau = 1;
        [flowin1,flowout1] = AcousticLaxFriedrich(0,-1,JA,JB,vp,tau);
        [flowin2,flowout2] = AcousticLaxFriedrich(cos(theta/2),sin(theta/2),JA,JB,vp,tau);
        [flowin3,flowout3] = AcousticLaxFriedrich(-sin(theta),cos(theta),JA,JB,vp,tau);
        [flowin4,flowout4] = AcousticLaxFriedrich(0,1,JA,JB,vp,tau);
        [flowin5,flowout5] = AcousticLaxFriedrich(-cos(theta/2),-sin(theta/2),JA,JB,vp,tau);
        [flowin6,flowout6] = AcousticLaxFriedrich(sin(theta),-cos(theta),JA,JB,vp,tau);
    elseif(strcmp(flux,'CentredFlux'))
        tau = 0;
        [flowin1,flowout1] = AcousticLaxFriedrich(0,-1,JA,JB,vp,tau);
        [flowin2,flowout2] = AcousticLaxFriedrich(cos(theta/2),sin(theta/2),JA,JB,vp,tau);
        [flowin3,flowout3] = AcousticLaxFriedrich(-sin(theta),cos(theta),JA,JB,vp,tau);
        [flowin4,flowout4] = AcousticLaxFriedrich(0,1,JA,JB,vp,tau);
        [flowin5,flowout5] = AcousticLaxFriedrich(-cos(theta/2),-sin(theta/2),JA,JB,vp,tau);
        [flowin6,flowout6] = AcousticLaxFriedrich(sin(theta),-cos(theta),JA,JB,vp,tau);
    elseif(strcmp(flux,'EngquistOsherFlux'))
        [flowin1,flowout1] = AcousticEngquistOsher(0,-1,JA,JB,vp);
        [flowin2,flowout2] = AcousticEngquistOsher(cos(theta/2),sin(theta/2),JA,JB,vp);
        [flowin3,flowout3] = AcousticEngquistOsher(-sin(theta),cos(theta),JA,JB,vp);
        [flowin4,flowout4] = AcousticEngquistOsher(0,1,JA,JB,vp);
        [flowin5,flowout5] = AcousticEngquistOsher(-cos(theta/2),-sin(theta/2),JA,JB,vp);
        [flowin6,flowout6] = AcousticEngquistOsher(sin(theta),-cos(theta),JA,JB,vp);
    elseif(strcmp(flux,'GodunovFlux'))
        [flowin1,flowout1] = AcousticGodunov(0,-1,vp);
        [flowin2,flowout2] = AcousticGodunov(cos(theta/2),sin(theta/2),vp);
        [flowin3,flowout3] = AcousticGodunov(-sin(theta),cos(theta),vp);
        [flowin4,flowout4] = AcousticGodunov(0,1,vp);
        [flowin5,flowout5] = AcousticGodunov(-cos(theta/2),-sin(theta/2),vp);
        [flowin6,flowout6] = AcousticGodunov(sin(theta),-cos(theta),vp);
    end
    kkinsp = kron(flowin1,F1)*minedge/(minedge*minedge*sin(theta))+kron(flowin2,F2)*2*minedge*sin(theta/2)/(minedge*minedge*sin(theta))+kron(flowin3,F3)*minedge/(minedge*minedge*sin(theta));
    kkoutsp = kron(flowout1,FF1)*minedge/(minedge*minedge*sin(theta))*phaseB+kron(flowout2,FF2)*2*minedge*sin(theta/2)/(minedge*minedge*sin(theta))+kron(flowout3,FF3)*minedge/(minedge*minedge*sin(theta))*phaseL;

    D11sp = kkinsp-kk;
    D12sp = kkoutsp;
%     clear kkin kk kkout
    
    %�ڶ�����Ԫ
    kk3 = JA*(-1/minedge)+JB*(cos(theta)/(minedge*sin(theta)));
    kk4 = JA*(0)+JB*(-1/(minedge*sin(theta)));
    kkk = kron(kk3,K1)+kron(kk4,K2);
    
%     [flowin4,flowout4] = AcousticLaxFriedrich(0,1,JA,JB,vp,tau);
%     [flowin5,flowout5] = AcousticLaxFriedrich(-cos(theta/2),-sin(theta/2),JA,JB,vp,tau);
%     [flowin6,flowout6] = AcousticLaxFriedrich(sin(theta),-cos(theta),JA,JB,vp,tau);

%     [flowin4,flowout4] = AcousticGodunov(0,1,vp);
%     [flowin5,flowout5] = AcousticGodunov(-cos(theta/2),-sin(theta/2),vp);
%     [flowin6,flowout6] = AcousticGodunov(sin(theta),-cos(theta),vp);
    
    kkin2sp = kron(flowin4,F1)*minedge/(minedge*minedge*sin(theta))+kron(flowin5,F2)*2*minedge*sin(theta/2)/(minedge*minedge*sin(theta))+kron(flowin6,F3)*minedge/(minedge*minedge*sin(theta));

    kkout2sp = kron(flowout4,FF1)*minedge/(minedge*minedge*sin(theta))*phaseT+kron(flowout5,FF2)*2*minedge*sin(theta/2)/(minedge*minedge*sin(theta))+kron(flowout6,FF3)*minedge/(minedge*minedge*sin(theta))*phaseR;

    D22sp = kkin2sp-kkk;
    D21sp = kkout2sp;
%     clear kkin2 kkk kkout2
    
    KKsp = [D11sp,D12sp;D21sp,D22sp];
    
%     clear D11 D12 D21 D22
    MM = [II, OO;OO, II];
    
    invMM = inv(MM);
    ZZsp = -invMM*KKsp;
    %% time format
    %% 3TVDRK
    if(strcmp(method,'3TVDRK'))
    %%
        for qrk=0.03 % 3th TVD RK          qrk=0.03;
            dtac=qrk*minedge*1.0000001/vp;
            DD=(eye(size(ZZsp)) + dtac*ZZsp+0.5*dtac^2*ZZsp^2+1/6*dtac^3*ZZsp^3);
            ccrk=eig(DD);
            if ( max(abs(ccrk)) > 1.000000000001 )
                break;
            end
        end
        % vp
        edisvp = atan(-imag(ccrk)./real(ccrk))/(qrk*2*pi*sp)-1;
        a = size(edisvp);
        flag=1;j=1;
        for k=1:a
            if abs(edisvp(k))<=flag
                flag = abs(edisvp(k));
                j=k;
            end
        end
        minedisvp = edisvp(j)+1;                                            % minedisvp   vp dispersion
        dissp = real(ccrk(j))/cos(atan(-imag(ccrk(j))./real(ccrk(j))));     % dissp       vp dissipation 
    %% WRK ��Ȩ��ʽ
    elseif (strcmp(method,'WRK'))
    %%
        for qrk2=0.1
            dtac=qrk2*minedge/vp;
            rr=(3-sqrt(3))/6;
            eta = 0.7;      % eta ��Χ [0,1]
            
            G1=(ZZsp + rr*dtac*ZZsp^2+eta*(rr*dtac)^2*ZZsp^3);
            G2=eye(size(ZZsp))+(1-2*rr)*dtac*G1;
            DD = eye(size(ZZsp))+dtac/2*(G1+G1*G2);
            ccrk=eig(DD);
            if ( max(abs(ccrk)) > 1.0000001 )
                break;
            end            
        end 
        
        % vp
        edisvp = atan(-imag(ccrk)./real(ccrk))/(qrk2*2*pi*sp)-1;
        a = size(edisvp);
        flag=1;j=1;
        for k=1:a
            if abs(edisvp(k))<=flag
                flag = abs(edisvp(k));
                j=k;
            end
        end
        minedisvp = edisvp(j)+1;                                            % minedisvp   vp dispersion
        dissp = real(ccrk(j))/cos(atan(-imag(ccrk(j))./real(ccrk(j))));     % dissp       vp dissipation            
     %% LP ����
    elseif(strcmp(method,'LF'))
     %%
        
    %% û��ʱ���ʽ
    elseif(strcmp(method,'semi'))
    %%
        for qrk=0.03     % qrk=0.03;
            ccrk=eig(ZZsp);
            if ( max(abs(ccrk)) > 1.000000000001 )
                break;
            end
        end

        %%  vp
        edisvp= -imag(ccrk)*minedge/(2*pi*sp*vp) -1;

        a = size(edisvp);
        flag=1;j=1;
        for k=1:a
            if abs(edisvp(k))<=flag
                flag = abs(edisvp(k));
                j=k;
            end
        end
        minedisvp = edisvp(j)+1;
        dissp = real(ccrk(j))*minedge/vp + 1;
    end
    
end
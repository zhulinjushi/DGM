function [flowin,flowout] = AcousticGodunov(nx,nz,vp)
    %% 
    flowin = zeros(3);
    flowout = zeros(3);
    
    flowin(1,1) = vp/2;
    flowin(1,2) = -vp*vp*nx/2;
    flowin(1,3) = -vp*vp*nz/2;
    flowin(2,1) = -nx/2;
    flowin(2,2) = nx*nx*vp/2;
    flowin(2,3) = nx*nz*vp/2;
    flowin(3,1) = -nz/2;
    flowin(3,2) = nx*nz*vp/2;
    flowin(3,3) = nz*nz*vp/2;
    
    flowout(1,1) = -vp/2;
    flowout(1,2) = -vp*vp*nx/2;
    flowout(1,3) = -vp*vp*nz/2;
    flowout(2,1) = -nx/2;
    flowout(2,2) = -nx*nx*vp/2;
    flowout(2,3) = -nx*nz*vp/2;
    flowout(3,1) = -nz/2;
    flowout(3,2) = -nx*nz*vp/2;
    flowout(3,3) = -nz*nz*vp/2;
    
end
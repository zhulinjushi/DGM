function script=matsub(p,a,b)

script=(2*p-a+3)*a/2+b+1;
clc;clear;close all;
%% order
vp = 2000;  %
rho = 2000;
f = 35;
%%
p = 1;
ktao = 1/p;
%%
gama = pi/72;
minedge1 = 10;
%%
mm = ceil(2*pi/gama);

refe = ones(1,length(0:mm));
%%  theta 
theta = pi/2;  

e1p = zeros(1,length(0:mm));
e1s = zeros(1,length(0:mm));
reference = zeros(1,length(0:mm));
angle = zeros(1,length(0:mm));
for k = 0:mm
    [minedisvp,dissp] = AcousticGridDispersion(vp,rho,f,p,ktao,theta,k*gama,minedge1,'CentredFlux','semi');
    e1p(k+1) = minedisvp;
    e1s(k+1) = dissp;
    reference(k+1) = 1;
    angle(k+1) = k*gama;
end

e2p = zeros(1,length(0:mm));
e2s = zeros(1,length(0:mm));
angle = zeros(1,length(0:mm));
for k = 0:mm
    [minedisvp,dissp] = AcousticGridDispersion(vp,rho,f,p,ktao,theta,k*gama,minedge1,'LaxFredrichsFlux','semi');
    e2p(k+1) = minedisvp;
    e2s(k+1) = dissp;
    angle(k+1) = k*gama;
end

e3p = zeros(1,length(0:mm));
e3s = zeros(1,length(0:mm));
angle = zeros(1,length(0:mm));
for k = 0:mm
    [minedisvp,dissp] = AcousticGridDispersion(vp,rho,f,p,ktao,theta,k*gama,minedge1,'GodunovFlux','semi');
    e3p(k+1) = minedisvp;
    e3s(k+1) = dissp;
    angle(k+1) = k*gama;
end

% e4p = zeros(1,length(0:mm));
% e4s = zeros(1,length(0:mm));
% angle = zeros(1,length(0:mm));
% for k = 0:mm
%     [minedisvp,dissp] = AcousticGridDispersion(vp,rho,f,p,ktao,theta,k*gama,minedge1,'GodunovFlux','semi');
%     e4p(k+1) = minedisvp;
%     e4s(k+1) = dissp;
%     angle(k+1) = k*gama;
% end


figure;
set(gcf,'unit','centimeters','position',[2 1 15 15]); 

plot(angle,e1p,'-','LineWidth',2,'Color',[1 0 0]); 
hold on;
plot(angle,e2p,'-','LineWidth',2,'Color',[0.13333 0.5451 0.13333]); 
hold on;
plot(angle,e3p,'-','LineWidth',2,'Color',[0.69804 0.13333 0.13333]); 
hold on;
% plot(angle,e4p,'-','LineWidth',2,'Color',[0.8549 0.64706 0.12549]); 
% hold on;


xlabel('\gamma','FontSize',13);
ylabel('R ','FontSize',13);
% axis([0,6.284,0.99,1.04]);
axis([0,6.284,0.999,1.05]); %1
% axis([0,6.284,0.999,1.0200]); %2
% axis([0,6.284,0.9995,1.007]);  %3
% axis([0,6.284,0.9999,1.002]);  %4
% axis([0,6.284,1,1.000008]);
set(gca,'XTick',0:0.7854:6.284);
set(gca,'XTicklabel',{'0','\pi/4','\pi/2','3\pi/4','\pi','5\pi/4','3\pi/2','7\pi/4','2\pi'});
set(gca,'YTick',1:0.01:1.05);   %1
set(gca,'YTicklabel',{'1','1.01','1.02','1.03','1.04','1.05'});
% set(gca,'YTick',0.999:0.004:1.020);   %2
% set(gca,'YTicklabel',{'0.999','1.003','1.007','1.011','1.015','1.019'});
% set(gca,'YTick',0.9995:0.0015:1.007); %3
% set(gca,'YTicklabel',{'0.9995','1.001','1.0025','1.004','1.0055','1.007'});
% set(gca,'YTick',1:0.0004:1.002); %4
% set(gca,'YTicklabel',{'1','1.0004','1.0008','1.0012','1.0016','1.002'});
% set(gca,'xgrid','on');
% set(gca,'ygrid','on');
set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
set(gca,'Linewidth',1.5,'GridAlpha',1);
% ll = legend('case 1','case 2');
legend('  Centred flux ','     LLF     flux ',' Godunov flux','Location','northwest');
set(gca,'FontSize',15);



figure;
set(gcf,'unit','centimeters','position',[2 1 15 15]); 

plot(angle,e1s,'-','LineWidth',2,'Color',[1 0 0]); 
hold on;
plot(angle,e2s,'-','LineWidth',2,'Color',[0.13333 0.5451 0.13333]); 
hold on;
plot(angle,e3s,'-','LineWidth',2,'Color',[0.69804 0.13333 0.13333]); 
hold on;

xlabel('\gamma','FontSize',13);
ylabel('S','FontSize',13);
axis([0,6.284,0.98,1.001]); %1

set(gca,'XTick',0:0.7854:6.284);
set(gca,'XTicklabel',{'0','\pi/4','\pi/2','3\pi/4','\pi','5\pi/4','3\pi/2','7\pi/4','2\pi'});
set(gca,'YTick', 0.98:0.004:1);   %1
set(gca,'YTicklabel',{'0.98','0.984','0.988','0.992','0.996','1'});
set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
set(gca,'Linewidth',1.5,'GridAlpha',1);
legend('  Centred flux ','     LLF     flux ',' Godunov flux','Location','southwest');
set(gca,'FontSize',15);












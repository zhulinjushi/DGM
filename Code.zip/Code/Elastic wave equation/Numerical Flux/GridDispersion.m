%% GridDispersion
function [minedisvp,dissp,minedisvs,disss] = GridDispersion(vp,vs,rho,fpeak,p,theta,gama,minedge,flux,method)
   %% Tensor product form
    mu=rho*vs^2;
    lambda=rho*vp^2-2*mu;
%     fmax=2*fpeak;

    bolmins=vs/fpeak;
    bolminp=vp/fpeak;

    N=(p+1)*(p+2)/2;

    s=minedge/bolmins*p;
    sp=minedge/bolminp*p;

%     A = 0.5*minedge^2*sin(theta);
%     J = 2*A;

%     O = zeros(N,N);
%     c0 = -1/rho;
%     c1 = -(lambda+2*mu);
%     c2 = -lambda;
%     c3 = -mu;
    %%
    [M,K1,K2,F1,F2,F3,Fnx]=eleOperator(p);

    FF1=Fnx{1,1};FF2=Fnx{2,2};FF3=Fnx{3,3};
%% �ſ˱Ⱦ���
    JA = zeros(5,5); 
    JB = zeros(5,5);
    
    JA(1,4) = -(lambda + 2*mu);
    JA(2,4) = -lambda;
    JA(3,5) = -mu;
    JA(4,1) = -1/rho;
    JA(5,3) = -1/rho;

    JB(1,5) = -lambda;
    JB(2,5) = -(lambda + 2*mu);
    JB(3,4) = -mu;
    JB(4,3) = -1/rho;
    JB(5,2) = -1/rho;   
%%
%%
    O = zeros(N,N);
%     I = eye(N);
    Init = eye(5);
    OO = kron(Init,O);
    II = kron(Init,M);
  %% P wave
    phaseT = exp(1i*2*pi*sp*cos(gama)*cos(theta))*exp(1i*2*pi*sp*sin(gama)*sin(theta));
    phaseB = exp(-1i*2*pi*sp*cos(gama)*cos(theta))*exp(-1i*2*pi*sp*sin(gama)*sin(theta));
    phaseL = exp(-1i*2*pi*sp*cos(gama));
    phaseR = exp(1i*2*pi*sp*cos(gama));  
   %%
       if(strcmp(flux,'LaxFredrichsFlux'))
           tau = 1;
           [flowin1,flowout1] = LaxFriedrich(0,-1,JA,JB,vp,tau);
           [flowin2,flowout2] = LaxFriedrich(cos(theta/2),sin(theta/2),JA,JB,vp,tau);
           [flowin3,flowout3] = LaxFriedrich(-sin(theta),cos(theta),JA,JB,vp,tau);
           [flowin4,flowout4] = LaxFriedrich(0,1,JA,JB,vp,tau);
           [flowin5,flowout5] = LaxFriedrich(-cos(theta/2),-sin(theta/2),JA,JB,vp,tau);
           [flowin6,flowout6] = LaxFriedrich(sin(theta),-cos(theta),JA,JB,vp,tau);
       elseif(strcmp(flux,'CentredFlux'))
           tau = 0;
           [flowin1,flowout1] = LaxFriedrich(0,-1,JA,JB,vp,tau);
           [flowin2,flowout2] = LaxFriedrich(cos(theta/2),sin(theta/2),JA,JB,vp,tau);
           [flowin3,flowout3] = LaxFriedrich(-sin(theta),cos(theta),JA,JB,vp,tau);
           [flowin4,flowout4] = LaxFriedrich(0,1,JA,JB,vp,tau);
           [flowin5,flowout5] = LaxFriedrich(-cos(theta/2),-sin(theta/2),JA,JB,vp,tau);
           [flowin6,flowout6] = LaxFriedrich(sin(theta),-cos(theta),JA,JB,vp,tau);
       elseif(strcmp(flux,'EngquistOsherFlux'))
           [flowin1,flowout1] = EngquistOsher(0,-1,vp,vs,rho);
           [flowin2,flowout2] = EngquistOsher(cos(theta/2),sin(theta/2),vp,vs,rho);
           [flowin3,flowout3] = EngquistOsher(-sin(theta),cos(theta),vp,vs,rho);
           [flowin4,flowout4] = EngquistOsher(0,1,vp,vs,rho);
           [flowin5,flowout5] = EngquistOsher(-cos(theta/2),-sin(theta/2),vp,vs,rho);
           [flowin6,flowout6] = EngquistOsher(sin(theta),-cos(theta),vp,vs,rho);
       elseif(strcmp(flux,'GodunovFlux'))
           [flowin1,flowout1] = Godunov(0,-1,vp,vs,rho);
           [flowin2,flowout2] = Godunov(cos(theta/2),sin(theta/2),vp,vs,rho);
           [flowin3,flowout3] = Godunov(-sin(theta),cos(theta),vp,vs,rho);
           [flowin4,flowout4] = Godunov(0,1,vp,vs,rho);
           [flowin5,flowout5] = Godunov(-cos(theta/2),-sin(theta/2),vp,vs,rho);
           [flowin6,flowout6] = Godunov(sin(theta),-cos(theta),vp,vs,rho);
       end
    %%
    %��һ����Ԫ
    kk1 = JA*(1/minedge)+JB*(-cos(theta)/(minedge*sin(theta)));
    kk2 = JA*(0)+JB*(1/(minedge*sin(theta)));
%     kk = kron(kk1,K1)+kron(kk2,K2);
    kk = kron(kk1,K1)+kron(kk2,K2);
    kkinsp = kron(flowin1,F1)*minedge/(minedge*minedge*sin(theta))+kron(flowin2,F2)*2*minedge*sin(theta/2)/(minedge*minedge*sin(theta))+kron(flowin3,F3)*minedge/(minedge*minedge*sin(theta));
    kkoutsp = kron(flowout1,FF1)*minedge/(minedge*minedge*sin(theta))*phaseB+kron(flowout2,FF2)*2*minedge*sin(theta/2)/(minedge*minedge*sin(theta))+kron(flowout3,FF3)*minedge/(minedge*minedge*sin(theta))*phaseL;

    D11sp = kkinsp-kk;
    D12sp = kkoutsp;
%     clear kkin kk kkout
    
    %�ڶ�����Ԫ
    kk3 = JA*(-1/minedge)+JB*(cos(theta)/(minedge*sin(theta)));
    kk4 = JA*(0)+JB*(-1/(minedge*sin(theta)));
    kkk = kron(kk3,K1)+kron(kk4,K2);
  
    kkin2sp = kron(flowin4,F1)*minedge/(minedge*minedge*sin(theta))+kron(flowin5,F2)*2*minedge*sin(theta/2)/(minedge*minedge*sin(theta))+kron(flowin6,F3)*minedge/(minedge*minedge*sin(theta));

    kkout2sp = kron(flowout4,FF1)*minedge/(minedge*minedge*sin(theta))*phaseT+kron(flowout5,FF2)*2*minedge*sin(theta/2)/(minedge*minedge*sin(theta))+kron(flowout6,FF3)*minedge/(minedge*minedge*sin(theta))*phaseR;

    D22sp = kkin2sp-kkk;
    D21sp = kkout2sp;
%     clear kkin2 kkk kkout2
    
    KKsp = [D11sp,D12sp;D21sp,D22sp];
    
%     clear D11 D12 D21 D22
    MM = [II, OO;OO, II];
    
    invMM = inv(MM);
    ZZsp = -invMM*KKsp;
    
    
       
    %% S wave
    phaseT = exp(1i*2*pi*s*cos(gama)*cos(theta))*exp(1i*2*pi*s*sin(gama)*sin(theta));
    phaseB = exp(-1i*2*pi*s*cos(gama)*cos(theta))*exp(-1i*2*pi*s*sin(gama)*sin(theta));
    phaseL = exp(-1i*2*pi*s*cos(gama));
    phaseR = exp(1i*2*pi*s*cos(gama));

        %%
    %��һ����Ԫ
    kkinss = kron(flowin1,F1)*minedge/(minedge*minedge*sin(theta))+kron(flowin2,F2)*2*minedge*sin(theta/2)/(minedge*minedge*sin(theta))+kron(flowin3,F3)*minedge/(minedge*minedge*sin(theta));
    kkoutss = kron(flowout1,FF1)*minedge/(minedge*minedge*sin(theta))*phaseB+kron(flowout2,FF2)*2*minedge*sin(theta/2)/(minedge*minedge*sin(theta))+kron(flowout3,FF3)*minedge/(minedge*minedge*sin(theta))*phaseL;

    D11ss = kkinss-kk;
    D12ss = kkoutss;
%     clear kkin kk kkout
    
    %�ڶ�����Ԫ
    kkin2ss = kron(flowin4,F1)*minedge/(minedge*minedge*sin(theta))+kron(flowin5,F2)*2*minedge*sin(theta/2)/(minedge*minedge*sin(theta))+kron(flowin6,F3)*minedge/(minedge*minedge*sin(theta));

    kkout2ss = kron(flowout4,FF1)*minedge/(minedge*minedge*sin(theta))*phaseT+kron(flowout5,FF2)*2*minedge*sin(theta/2)/(minedge*minedge*sin(theta))+kron(flowout6,FF3)*minedge/(minedge*minedge*sin(theta))*phaseR;

    D22ss = kkin2ss-kkk;
    D21ss = kkout2ss;
%     clear kkin2 kkk kkout2
    
    KKss = [D11ss,D12ss;D21ss,D22ss];
    
%     clear D11 D12 D21 D22
    
    ZZss = -invMM*KKss;
    %% time format
    %% 3TVDRK
    if(strcmp(method,'3TVDRK'))
    %%
        for qrk=0.03 % 3th TVD RK          qrk=0.03;
            dtac=qrk*minedge/vp;
            DD=(eye(size(ZZsp)) + dtac*ZZsp+0.5*dtac^2*ZZsp^2+1/6*dtac^3*ZZsp^3);
            ccrk=eig(DD);
            if ( max(abs(ccrk)) > 1.000000000001 )
                break;
            end
        end
        % vp
        edisvp = atan(-imag(ccrk)./real(ccrk))/(qrk*2*pi*sp)-1;
        a = size(edisvp);
        flag=1;j=1;
        for k=1:a
            if abs(edisvp(k))<=flag
                flag = abs(edisvp(k));
                j=k;
            end
        end
        minedisvp = edisvp(j)+1;                                            % minedisvp   vp dispersion
        dissp = real(ccrk(j))/cos(atan(-imag(ccrk(j))./real(ccrk(j))));     % dissp       vp dissipation 
        
        % vs
        DD=(eye(size(ZZss)) + dtac*ZZss+0.5*dtac^2*ZZss^2+1/6*dtac^3*ZZss^3);
        ccrk=eig(DD);
        edisvs = minedge*atan(-imag(ccrk)./real(ccrk))/(vs*dtac*2*pi*s)-1;    %???????
        a = size(edisvs);
        flag=1;j=1;
        for k=1:a
            if abs(edisvs(k))<=flag
                flag = abs(edisvs(k));
                j=k;
            end
        end
        minedisvs = edisvs(j)+1;                                               % minedisvs   vs dispersion
        disss=real(ccrk(j))/cos(atan(-imag(ccrk(j))./real(ccrk(j))));          % disss       vs dissipation 
    %% WRK ��Ȩ��ʽ
    elseif (strcmp(method,'WRK'))
    %%
        for qrk2=0.1
            dtac=qrk2*minedge/vp;
            rr=(3-sqrt(3))/6;
            eta = 0.7;      % eta ��Χ [0,1]
            
            G1=(ZZsp + rr*dtac*ZZsp^2+eta*(rr*dtac)^2*ZZsp^3);
            G2=eye(size(ZZsp))+(1-2*rr)*dtac*G1;
            DD = eye(size(ZZsp))+dtac/2*(G1+G1*G2);
            ccrk=eig(DD);
            if ( max(abs(ccrk)) > 1.0000001 )
                break;
            end            
        end 
        
        % vp
        edisvp = atan(-imag(ccrk)./real(ccrk))/(qrk2*2*pi*sp)-1;
        a = size(edisvp);
        flag=1;j=1;
        for k=1:a
            if abs(edisvp(k))<=flag
                flag = abs(edisvp(k));
                j=k;
            end
        end
        minedisvp = edisvp(j)+1;                                            % minedisvp   vp dispersion
        dissp = real(ccrk(j))/cos(atan(-imag(ccrk(j))./real(ccrk(j))));     % dissp       vp dissipation 
        
        % vs
        G1=(ZZss + rr*dtac*ZZss^2+eta*(rr*dtac)^2*ZZss^3);
        G2=eye(size(ZZss))+(1-2*rr)*dtac*G1;
        DD = eye(size(ZZss))+dtac/2*(G1+G1*G2);
%         DD=(eye(size(ZZss)) + dtac*ZZss+0.5*dtac^2*ZZss^2+1/6*dtac^3*ZZss^3);
        ccrk=eig(DD);
        edisvs = minedge*atan(-imag(ccrk)./real(ccrk))/(vs*dtac*2*pi*s)-1;
        a = size(edisvs);
        flag=1;j=1;
        for k=1:a
            if abs(edisvs(k))<=flag
                flag = abs(edisvs(k));
                j=k;
            end
        end
        minedisvs = edisvs(j)+1;                                               % minedisvs   vs dispersion
        disss=real(ccrk(j))/cos(atan(-imag(ccrk(j))./real(ccrk(j))));          % disss       vs dissipation                       
     %% LP ����
    elseif(strcmp(method,'LF'))
     %%
        
    %% û��ʱ���ʽ
    elseif(strcmp(method,'semi'))
    %%
        for qrk=0.01     % 3th TVD RK          qrk=0.03;
%             dtac=qrk*minedge/vp;       
            ccrk=eig(ZZsp);
            if ( max(abs(ccrk)) > 1.000000000001 )
                break;
            end
        end
        
        %%  vp        
       edisvp= imag(ccrk)*minedge/(2*pi*sp*vp) -1;
        
        a = size(edisvp);
        flag=1;j=1;
        for k=1:a
            if abs(edisvp(k))<=flag
                flag = abs(edisvp(k));
                j=k;
            end
        end
        minedisvp = edisvp(j)+1;  
        % minedisvp   vp dispersion
%         dissp = real(ccrk(j))/cos(atan(-imag(ccrk(j))./real(ccrk(j))));     % dissp       vp dissipation
        dissp = real(ccrk(j))*minedge/vp;
        
       %% vs  
        cccs=eig(ZZss);
        edisvs = imag(cccs)*minedge/(2*pi*s*vs) -1;
        a = size(edisvs);
        flag=1;j=1;
        for k=1:a
            if abs(edisvs(k))<=flag
                flag = abs(edisvs(k));
                j=k;
            end
        end
        minedisvs = edisvs(j)+1;                                               % minedisvs   vs dispersion
        disss = real(cccs(j))*minedge/vs+1;
    end
    
end
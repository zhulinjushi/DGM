clc;clear;close all;
%% semi-discrete elastic wave
vp = 3600;
% vs = 2264; 
vs = 2000; % 1,2,4
rho = 2000;
f = 30;
%%
p = 1;
%%
% p = 1; sample_ratio = 0.2;  % p=1
% minedge1 = sample_ratio*vp*p/(f);
minedge1 = 10;
gama = pi/72;
mm = ceil(2*pi/gama);
%%  theta 
theta = pi/2; 
e1p = zeros(1,length(0:mm));
e1s = zeros(1,length(0:mm));
e1ps = zeros(1,length(0:mm));
e1ss = zeros(1,length(0:mm));
angle = zeros(1,length(0:mm));
for k = 0:mm
    [minedisvp,dissp,minedisvs,disss] = GridDispersion(vp,vs,rho,f,p,theta,k*gama,minedge1,'CentredFlux','semi');
    e1p(k+1) = minedisvp;
    e1s(k+1) = dissp;
    e1ps(k+1) = minedisvs;
    e1ss(k+1) = disss;
    angle(k+1) = k*gama;
end

e2p = zeros(1,length(0:mm));
e2s = zeros(1,length(0:mm));
e2ps = zeros(1,length(0:mm));
e2ss = zeros(1,length(0:mm));

for k = 0:mm
    [minedisvp,dissp,minedisvs,disss] = GridDispersion(vp,vs,rho,f,p,theta,k*gama,minedge1,'LaxFredrichsFlux','semi');
    e2p(k+1) = minedisvp;
    e2s(k+1) = dissp;
    e2ps(k+1) = minedisvs;
    e2ss(k+1) = disss;
end

e3p = zeros(1,length(0:mm));
e3s = zeros(1,length(0:mm));
e3ps = zeros(1,length(0:mm));
e3ss = zeros(1,length(0:mm));
for k = 0:mm
    [minedisvp,dissp,minedisvs,disss] = GridDispersion(vp,vs,rho,f,p,theta,k*gama,minedge1,'GodunovFlux','semi');
    e3p(k+1) = minedisvp;
    e3s(k+1) = dissp;
    e3ps(k+1) = minedisvs;
    e3ss(k+1) = disss;
end

% %%
% % eps = 0.0005;
% eps = 0;
% figure;
% set(gcf,'unit','centimeters','position',[2 1 15 15]); 
% 
% plot(angle,e1p+eps,'-','LineWidth',2,'Color',[1 0 0]); 
% hold on;
% plot(angle,e2p+eps,'-','LineWidth',2,'Color',[0.13333 0.5451 0.13333]); 
% hold on;
% plot(angle,e3p+eps,'-','LineWidth',2,'Color',[0.69804 0.13333 0.13333]); 
% hold on;
% xlabel('\gamma','FontSize',13);
% ylabel('R ','FontSize',13);
% axis([0,6.284,0.9998,1.008]); %1
% % axis([0,6.284,0.99995,1.001]); %2
% % axis([0,6.284,0.99999,1.0001]);  %3
% % axis([0,6.284,0.999999,1.00002]);  %4
% set(gca,'XTick',0:0.7854:6.284);
% set(gca,'XTicklabel',{'0','\pi/4','\pi/2','3\pi/4','\pi','5\pi/4','3\pi/2','7\pi/4','2\pi'});
% set(gca,'YTick',1.0005:0.0015:1.008);   %1
% set(gca,'YTicklabel',{'1','1.01','1.02','1.03','1.04','1.05'});
% % set(gca,'YTick',1:0.0002:1.001);   %2
% % set(gca,'YTicklabel',{'1','1.004','1.008','1.012','1.018','1.02'});
% % set(gca,'YTick',1:0.00002:1.0001); %3
% % set(gca,'YTicklabel',{'1','1.0012','1.0024','1.0036','1.0048','1.006'});
% % set(gca,'YTick',1:0.000004:1.00002); %4
% % set(gca,'YTicklabel',{'1','1.0004','1.0008','1.0012','1.0016','1.002'});
% % set(gca,'xgrid','on');
% % set(gca,'ygrid','on');
% set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
% set(gca,'Linewidth',1.5,'GridAlpha',1);
% % ll = legend('case 1','case 2');
% legend('   Centred flux Vp','     LLF     flux Vp',' Godunov flux Vp','Location','northwest');
% set(gca,'FontSize',15);
% 
% 
% 
% 
%%
figure;
set(gcf,'unit','centimeters','position',[2 1 15 15]); 

plot(angle,e1ps,'--','LineWidth',2,'Color',[1 0 0]); 
hold on;
plot(angle,e2ps,'--','LineWidth',2,'Color',[0.13333 0.5451 0.13333]); 
hold on;
plot(angle,e3ps,'--','LineWidth',2,'Color',[0.69804 0.13333 0.13333]); 
hold on;
xlabel('\gamma','FontSize',13);
ylabel('R ','FontSize',13);
axis([0,6.284,0.995,1.05]); %1
% axis([0,6.284,0.999,1.0200]); %2
% axis([0,6.284,0.9999,1.001]);  %3
% axis([0,6.284,0.9999,1.002]);  %4
set(gca,'XTick',0:0.7854:6.284);
set(gca,'XTicklabel',{'0','\pi/4','\pi/2','3\pi/4','\pi','5\pi/4','3\pi/2','7\pi/4','2\pi'});
set(gca,'YTick',1:0.01:1.05);   %1
set(gca,'YTicklabel',{'1','1.01','1.02','1.03','1.04','1.05'});
% set(gca,'YTick',1:0.004:1.020);   %2
% set(gca,'YTicklabel',{'1','1.004','1.008','1.012','1.018','1.02'});
% set(gca,'YTick',1:0.0002:1.001); %3
% set(gca,'YTicklabel',{'1','1.0012','1.0024','1.0036','1.0048','1.006'});
% set(gca,'YTick',1:0.0004:1.002); %4
% set(gca,'YTicklabel',{'1','1.0004','1.0008','1.0012','1.0016','1.002'});
% set(gca,'xgrid','on');
% set(gca,'ygrid','on');
set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
set(gca,'Linewidth',1.5,'GridAlpha',1);
% ll = legend('case 1','case 2');
legend('   Centred flux Vs','     LLF     flux Vs',' Godunov flux Vs','Location','northwest');
set(gca,'FontSize',15);

%%
% figure;
% set(gcf,'unit','centimeters','position',[2 1 15 15]); 
% 
% plot(angle,e1s,'--','LineWidth',2,'Color',[1 0 0]); 
% hold on;
% plot(angle,e2s,'--','LineWidth',2,'Color',[0.13333 0.5451 0.13333]); 
% hold on;
% plot(angle,e3s,'--','LineWidth',2,'Color',[0.69804 0.13333 0.13333]); 
% hold on;
% xlabel('\gamma','FontSize',13);
% ylabel('S','FontSize',13);
%%
figure;
set(gcf,'unit','centimeters','position',[2 1 15 15]); 

plot(angle,e1ss,'--','LineWidth',2,'Color',[1 0 0]); 
hold on;
plot(angle,e2ss,'--','LineWidth',2,'Color',[0.13333 0.5451 0.13333]); 
hold on;
plot(angle,e3ss,'--','LineWidth',2,'Color',[0.69804 0.13333 0.13333]); 
hold on;
xlabel('\gamma','FontSize',13);
ylabel('S','FontSize',13);
axis([0,6.284,0.985,1.001]);
set(gca,'XTick',0:0.7854:6.284);
set(gca,'XTicklabel',{'0','\pi/4','\pi/2','3\pi/4','\pi','5\pi/4','3\pi/2','7\pi/4','2\pi'});
set(gca,'YTick', 0.985:0.003:1);   %1
set(gca,'YTicklabel',{'0.985','0.988','0.991','0.994','0.997','1'});
set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
set(gca,'Linewidth',1.5,'GridAlpha',1);
legend('  Centred flux ','     LLF     flux ',' Godunov flux','Location','southwest');
set(gca,'FontSize',15);


function [flowin,flowout] = LaxFriedrich(nx,nz,A,B,vmax,tao)
    %% tao =1 laxfriedrich flux or ta0 =0 center flux
    I = eye(5);
    flowin = (nx*A+nz*B+tao*vmax*I)/2;
    flowout = (nx*A+nz*B-tao*vmax*I)/2;
end
clc;clear;close all;
%% order
%% ���Բ�Ƶɢ
vp = 3600;
% vs = 2264; % 3��
vs = 2564; % 1,2,4
rho = 2000;
f = 25;
theta = pi/2;
%% ���Ʋ����������
p = 2;
%%   vp/(f*2)��sp=[0,0.5], vp/f,��sp=[0,1]
maxminedge = ceil(vp/f/2);
bolminp = vp/f;
vpsamplepoint =zeros(1,maxminedge);
for k = 1:maxminedge
    vpsamplepoint(k) = k/bolminp;
end
%%
gama = pi/12;

e1p = zeros(1,length(1:maxminedge));
e1s = zeros(1,length(1:maxminedge));
e1ps = zeros(1,length(1:maxminedge));
e1ss = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp,minedisvs,disss] = GridDispersion(vp,vs,rho,f,p,theta,gama,k,'LaxFredrichsFlux','semi');
    e1p(k) = minedisvp;
    e1s(k) = dissp;
    e1ps(k) = minedisvs;
    e1ss(k) = disss;
end

e2p = zeros(1,length(1:maxminedge));
e2s = zeros(1,length(1:maxminedge));
e2ps = zeros(1,length(1:maxminedge));
e2ss = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp,minedisvs,disss] = GridDispersion2(vp,vs,rho,f,p,theta,gama,k,'LaxFredrichsFlux','semi');
    e2p(k) = minedisvp;
    e2s(k) = dissp;
    e2ps(k) = minedisvs;
    e2ss(k) = disss;
end

e3p = zeros(1,length(1:maxminedge));
e3s = zeros(1,length(1:maxminedge));
e3ps = zeros(1,length(1:maxminedge));
e3ss = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp,minedisvs,disss] = GridDispersion3(vp,vs,rho,f,p,theta,gama,k,'LaxFredrichsFlux','semi');
    e3p(k) = minedisvp;
    e3s(k) = dissp;
    e3ps(k) = minedisvs;
    e3ss(k) = disss;
end

gama = pi/3;

e4p = zeros(1,length(1:maxminedge));
e4s = zeros(1,length(1:maxminedge));
e4ps = zeros(1,length(1:maxminedge));
e4ss = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp,minedisvs,disss] = GridDispersion(vp,vs,rho,f,p,theta,gama,k,'LaxFredrichsFlux','semi');
    e4p(k) = minedisvp;
    e4s(k) = dissp;
    e4ps(k) = minedisvs;
    e4ss(k) = disss;
end

e5p = zeros(1,length(1:maxminedge));
e5s = zeros(1,length(1:maxminedge));
e5ps = zeros(1,length(1:maxminedge));
e5ss = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp,minedisvs,disss] = GridDispersion2(vp,vs,rho,f,p,theta,gama,k,'LaxFredrichsFlux','semi');
    e5p(k) = minedisvp;
    e5s(k) = dissp;
    e5ps(k) = minedisvs;
    e5ss(k) = disss;
end

e6p = zeros(1,length(1:maxminedge));
e6s = zeros(1,length(1:maxminedge));
e6ps = zeros(1,length(1:maxminedge));
e6ss = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp,minedisvs,disss] = GridDispersion3(vp,vs,rho,f,p,theta,gama,k,'LaxFredrichsFlux','semi');
    e6p(k) = minedisvp;
    e6s(k) = dissp;
    e6ps(k) = minedisvs;
    e6ss(k) = disss;
end

gama = pi/2;

e7p = zeros(1,length(1:maxminedge));
e7s = zeros(1,length(1:maxminedge));
e7ps = zeros(1,length(1:maxminedge));
e7ss = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp,minedisvs,disss] = GridDispersion(vp,vs,rho,f,p,theta,gama,k,'LaxFredrichsFlux','semi');
    e7p(k) = minedisvp;
    e7s(k) = dissp;
    e7ps(k) = minedisvs;
    e7ss(k) = disss;
end

e8p = zeros(1,length(1:maxminedge));
e8s = zeros(1,length(1:maxminedge));
e8ps = zeros(1,length(1:maxminedge));
e8ss = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp,minedisvs,disss] = GridDispersion2(vp,vs,rho,f,p,theta,gama,k,'LaxFredrichsFlux','semi');
    e8p(k) = minedisvp;
    e8s(k) = dissp;
    e8ps(k) = minedisvs;
    e8ss(k) = disss;
end

e9p = zeros(1,length(1:maxminedge));
e9s = zeros(1,length(1:maxminedge));
e9ps = zeros(1,length(1:maxminedge));
e9ss = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp,minedisvs,disss] = GridDispersion3(vp,vs,rho,f,p,theta,gama,k,'LaxFredrichsFlux','semi');
    e9p(k) = minedisvp;
    e9s(k) = dissp;
    e9ps(k) = minedisvs;
    e9ss(k) = disss;
end

gama = 3*pi/4;

e10p = zeros(1,length(1:maxminedge));
e10s = zeros(1,length(1:maxminedge));
e10ps = zeros(1,length(1:maxminedge));
e10ss = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp,minedisvs,disss] = GridDispersion(vp,vs,rho,f,p,theta,gama,k,'LaxFredrichsFlux','semi');
    e10p(k) = minedisvp;
    e10s(k) = dissp;
    e10ps(k) = minedisvs;
    e10ss(k) = disss;
end

e11p = zeros(1,length(1:maxminedge));
e11s = zeros(1,length(1:maxminedge));
e11ps = zeros(1,length(1:maxminedge));
e11ss = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp,minedisvs,disss] = GridDispersion2(vp,vs,rho,f,p,theta,gama,k,'LaxFredrichsFlux','semi');
    e11p(k) = minedisvp;
    e11s(k) = dissp;
    e11ps(k) = minedisvs;
    e11ss(k) = disss;
end

e12p = zeros(1,length(1:maxminedge));
e12s = zeros(1,length(1:maxminedge));
e12ps = zeros(1,length(1:maxminedge));
e12ss = zeros(1,length(1:maxminedge));
for k = 1:maxminedge
    [minedisvp,dissp,minedisvs,disss] = GridDispersion3(vp,vs,rho,f,p,theta,gama,k,'LaxFredrichsFlux','semi');
    e12p(k) = minedisvp;
    e12s(k) = dissp;
    e12ps(k) = minedisvs;
    e12ss(k) = disss;
end
%% ��ͼ
figure;
set(gcf,'unit','centimeters','position',[20 1 15 15]); 
% polarplot(angle,e1p,'--b','LineWidth',2.5); 

plot(vpsamplepoint(1:3:end),e1p(1:3:end),'^','LineWidth',2,'Color',[1 0 0]); 
hold on;
plot(vpsamplepoint(2:3:end),e2p(2:3:end),'s','LineWidth',2,'Color',[1 0 0]); 
hold on;
plot(vpsamplepoint(3:3:end),e3p(3:3:end),'*','LineWidth',2,'Color',[1 0 0]); 
hold on;

plot(vpsamplepoint(1:3:end),e4p(1:3:end),'^','LineWidth',2,'Color',[0.13333 0.5451 0.13333]); 
hold on;
plot(vpsamplepoint(2:3:end),e5p(2:3:end),'s','LineWidth',2,'Color',[0.13333 0.5451 0.13333]); 
hold on;
plot(vpsamplepoint(3:3:end),e6p(3:3:end),'*','LineWidth',2,'Color',[0.13333 0.5451 0.13333]); 
hold on;

plot(vpsamplepoint(1:3:end),e7p(1:3:end),'^','LineWidth',2,'Color',[0.69804 0.13333 0.13333]); 
hold on;
plot(vpsamplepoint(2:3:end),e8p(2:3:end),'s','LineWidth',2,'Color',[0.69804 0.13333 0.13333]); 
hold on;
plot(vpsamplepoint(3:3:end),e9p(3:3:end),'*','LineWidth',2,'Color',[0.69804 0.13333 0.13333]); 
hold on;

plot(vpsamplepoint(1:3:end),e10p(1:3:end),'^','LineWidth',2,'Color',[0.6 0.19608 0.8]); 
hold on;
plot(vpsamplepoint(2:3:end),e11p(2:3:end),'s','LineWidth',2,'Color',[0.6 0.19608 0.8]); 
hold on;
plot(vpsamplepoint(3:3:end),e12p(3:3:end),'*','LineWidth',2,'Color',[0.6 0.19608 0.8]); 
hold on;


plot(vpsamplepoint,e1p,'-','LineWidth',1,'Color',[0 0 0]); 
hold on;
plot(vpsamplepoint,e4p,'-','LineWidth',1,'Color',[0 0 0]); 
hold on;
plot(vpsamplepoint,e7p,'-','LineWidth',1,'Color',[0 0 0]); 
hold on;
plot(vpsamplepoint,e10p,'-','LineWidth',1,'Color',[0 0 0]); 
hold on;

% axis([0,0.30,0.999,1.05]); %1��
axis([0,0.30,0.99996,1.0025]);  %2��
% axis([0,0.30,0.999999,1.00005]); %3��
xlabel('\delta','FontSize',13);  
ylabel('R ','FontSize',13);
set(gca,'XTick',0:0.05:0.3);
set(gca,'XTicklabel',{'0','0.05','0.1','0.15','0.2','0.25','0.3'});
% set(gca,'YTick',1:0.01:1.05);%1��
set(gca,'YTick',1:0.0005:1.0025);  %2��
% set(gca,'YTick',1:0.00001:1.00005);%3��
set(gca,'YTicklabel',{'1','1.01','1.02','1.03','1.04','1.05'});
set(gca,'FontSize',15);
set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
set(gca,'Linewidth',1.5,'GridAlpha',1);
legend('K D  \gamma = \pi/12','Monomial \gamma = \pi/12','Legendre  \gamma = \pi/12',...
       'K D  \gamma = \pi/3','Monomial  \gamma = \pi/3','Legendre   \gamma = \pi/3',...
       'K D  \gamma = \pi/2','Monomial  \gamma = \pi/2','Legendre  \gamma = \pi/2',...
       'K D  \gamma = 3\pi/4','Monomial \gamma = 3\pi/4','Legendre  \gamma = 3\pi/4','Location','northwest');
   
   %% ��ͼ
figure;
set(gcf,'unit','centimeters','position',[20 1 15 15]); 
% polarplot(angle,e1p,'--b','LineWidth',2.5); 

plot(vpsamplepoint(1:3:end),e1ps(1:3:end),'^','LineWidth',2,'Color',[1 0 0]); 
hold on;
plot(vpsamplepoint(2:3:end),e2ps(2:3:end),'s','LineWidth',2,'Color',[1 0 0]); 
hold on;
plot(vpsamplepoint(3:3:end),e3ps(3:3:end),'*','LineWidth',2,'Color',[1 0 0]); 
hold on;

plot(vpsamplepoint(1:3:end),e4ps(1:3:end),'^','LineWidth',2,'Color',[0.13333 0.5451 0.13333]); 
hold on;
plot(vpsamplepoint(2:3:end),e5ps(2:3:end),'s','LineWidth',2,'Color',[0.13333 0.5451 0.13333]); 
hold on;
plot(vpsamplepoint(3:3:end),e6ps(3:3:end),'*','LineWidth',2,'Color',[0.13333 0.5451 0.13333]); 
hold on;

plot(vpsamplepoint(1:3:end),e7ps(1:3:end),'^','LineWidth',2,'Color',[0.69804 0.13333 0.13333]); 
hold on;
plot(vpsamplepoint(2:3:end),e8ps(2:3:end),'s','LineWidth',2,'Color',[0.69804 0.13333 0.13333]); 
hold on;
plot(vpsamplepoint(3:3:end),e9ps(3:3:end),'*','LineWidth',2,'Color',[0.69804 0.13333 0.13333]); 
hold on;

plot(vpsamplepoint(1:3:end),e10ps(1:3:end),'^','LineWidth',2,'Color',[0.6 0.19608 0.8]); 
hold on;
plot(vpsamplepoint(2:3:end),e11ps(2:3:end),'s','LineWidth',2,'Color',[0.6 0.19608 0.8]); 
hold on;
plot(vpsamplepoint(3:3:end),e12ps(3:3:end),'*','LineWidth',2,'Color',[0.6 0.19608 0.8]); 
hold on;


plot(vpsamplepoint,e1ps,'--','LineWidth',1,'Color',[0 0 0]); 
hold on;
plot(vpsamplepoint,e4ps,'--','LineWidth',1,'Color',[0 0 0]); 
hold on;
plot(vpsamplepoint,e7ps,'--','LineWidth',1,'Color',[0 0 0]); 
hold on;
plot(vpsamplepoint,e10ps,'--','LineWidth',1,'Color',[0 0 0]); 
hold on;

% axis([0,0.30,0.999,1.05]); %1��
axis([0,0.30,0.99996,1.0025]);  %2��
% axis([0,0.30,0.999999,1.00005]); %3��
xlabel('\delta','FontSize',13);
ylabel('R ','FontSize',13);
set(gca,'XTick',0:0.05:0.3);
set(gca,'XTicklabel',{'0','0.05','0.1','0.15','0.2','0.25','0.3'});
% set(gca,'YTick',1:0.01:1.05);%1��
set(gca,'YTick',1:0.0005:1.0025);%2��
% set(gca,'YTick',1:0.00001:1.00005);%3��
set(gca,'YTicklabel',{'1','1.01','1.02','1.03','1.04','1.05'});
set(gca,'FontSize',15);
set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
set(gca,'Linewidth',1.5,'GridAlpha',1);
legend('K D  \gamma = \pi/12','Monomial \gamma = \pi/12','Legendre  \gamma = \pi/12',...
       'K D  \gamma = \pi/3','Monomial  \gamma = \pi/3','Legendre   \gamma = \pi/3',...
       'K D  \gamma = \pi/2','Monomial  \gamma = \pi/2','Legendre  \gamma = \pi/2',...
       'K D  \gamma = 3\pi/4','Monomial \gamma = 3\pi/4','Legendre  \gamma = 3\pi/4','Location','northwest');

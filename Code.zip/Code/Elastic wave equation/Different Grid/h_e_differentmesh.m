clc;clear;close all;
%% semi-discrete elastic wave
vp = 2600;
% vs = 2264; % 3��
vs = 2000; % 1,2,4
rho = 2000;
f = 30;
%%
p = 3;
%%
% p = 1; sample_ratio = 0.2;  % p=1
% minedge1 = sample_ratio*vp*p/(f);
minedge1 = 10;
gama = pi/72;
mm = ceil(2*pi/gama);
%%  theta 
theta = 2*pi/3;  
e1p = zeros(1,length(0:mm));
e1s = zeros(1,length(0:mm));
e1ps = zeros(1,length(0:mm));
e1ss = zeros(1,length(0:mm));
angle = zeros(1,length(0:mm));
for k = 0:mm
    [minedisvp,dissp,minedisvs,disss] = GridDispersion(vp,vs,rho,f,p,theta,k*gama,minedge1,'LaxFredrichsFlux','semi');
    e1p(k+1) = minedisvp;
    e1s(k+1) = dissp;
    e1ps(k+1) = minedisvs;
    e1ss(k+1) = disss;
    angle(k+1) = k*gama;
end

theta = pi/2;  %ֱ��������
e2p = zeros(1,length(0:mm));
e2s = zeros(1,length(0:mm));
e2ps = zeros(1,length(0:mm));
e2ss = zeros(1,length(0:mm));

for k = 0:mm
    [minedisvp,dissp,minedisvs,disss] = GridDispersion(vp,vs,rho,f,p,theta,k*gama,minedge1,'LaxFredrichsFlux','semi');
    e2p(k+1) = minedisvp;
    e2s(k+1) = dissp;
    e2ps(k+1) = minedisvs;
    e2ss(k+1) = disss;
end

theta = pi/3;  %ֱ��������
e3p = zeros(1,length(0:mm));
e3s = zeros(1,length(0:mm));
e3ps = zeros(1,length(0:mm));
e3ss = zeros(1,length(0:mm));
for k = 0:mm
    [minedisvp,dissp,minedisvs,disss] = GridDispersion(vp,vs,rho,f,p,theta,k*gama,minedge1,'LaxFredrichsFlux','semi');
    e3p(k+1) = minedisvp;
    e3s(k+1) = dissp;
    e3ps(k+1) = minedisvs;
    e3ss(k+1) = disss;
end

theta = pi/6;  %ֱ��������
e4p = zeros(1,length(0:mm));
e4s = zeros(1,length(0:mm));
e4ps = zeros(1,length(0:mm));
e4ss = zeros(1,length(0:mm));
for k = 0:mm
    [minedisvp,dissp,minedisvs,disss] = GridDispersion(vp,vs,rho,f,p,theta,k*gama,minedge1,'LaxFredrichsFlux','semi');
    e4p(k+1) = minedisvp;
    e4s(k+1) = dissp;
    e4ps(k+1) = minedisvs;
    e4ss(k+1) = disss;
end
%%
% eps = 0.0005;
eps = 0;
figure;
set(gcf,'unit','centimeters','position',[2 1 15 15]); 

plot(angle,e1p+eps,'-','LineWidth',2,'Color',[1 0 0]); 
hold on;
plot(angle,e2p+eps,'-','LineWidth',2,'Color',[0.13333 0.5451 0.13333]); 
hold on;
plot(angle,e3p+eps,'-','LineWidth',2,'Color',[0.69804 0.13333 0.13333]); 
hold on;
plot(angle,e4p+eps,'-','LineWidth',2,'Color',[0.8549 0.64706 0.12549]); 
hold on;
xlabel('\gamma','FontSize',13);
ylabel('R ','FontSize',13);
% axis([0,6.284,0.9998,1.008]); %1
% axis([0,6.284,0.9999,1.003]); %2
axis([0,6.284,0.99995,1.0015]);  %3
% axis([0,6.284,0.999999,1.00002]);  %4
set(gca,'XTick',0:0.7854:6.284);
set(gca,'XTicklabel',{'0','\pi/4','\pi/2','3\pi/4','\pi','5\pi/4','3\pi/2','7\pi/4','2\pi'});
% set(gca,'YTick',1.0005:0.0015:1.008);   %1
% set(gca,'YTicklabel',{'1','1.01','1.02','1.03','1.04','1.05'});
% set(gca,'YTick',1:0.0006:1.003);   %2
% set(gca,'YTicklabel',{'1','1.0006','1.0012','1.0018','1.0024','1.003'});
set(gca,'YTick',1:0.0003:1.0015); %3
set(gca,'YTicklabel',{'1','1.0003','1.0006','1.0009','1.0012','1.0015'});
% set(gca,'YTick',1:0.000004:1.00002); %4
% set(gca,'YTicklabel',{'1','1.0004','1.0008','1.0012','1.0016','1.002'});
% set(gca,'xgrid','on');
% set(gca,'ygrid','on');
set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
set(gca,'Linewidth',1.5,'GridAlpha',1);
% ll = legend('case 1','case 2');
legend('Case 1','Case 2','Case 3','Case 4','Location','northwest');
set(gca,'FontSize',15);




%%
figure;
set(gcf,'unit','centimeters','position',[2 1 15 15]); 

plot(angle,e1ps,'--','LineWidth',2,'Color',[1 0 0]); 
hold on;
plot(angle,e2ps,'--','LineWidth',2,'Color',[0.13333 0.5451 0.13333]); 
hold on;
plot(angle,e3ps,'--','LineWidth',2,'Color',[0.69804 0.13333 0.13333]); 
hold on;
plot(angle,e4ps,'--','LineWidth',2,'Color',[0.8549 0.64706 0.12549]); 
hold on;
xlabel('\gamma','FontSize',13);
ylabel('R ','FontSize',13);
% axis([0,6.284,0.995,1.05]); %1
% axis([0,6.284,0.9999,1.003]); %2
axis([0,6.284,0.99995,1.0015]);  %3
% axis([0,6.284,0.9999,1.002]);  %4
set(gca,'XTick',0:0.7854:6.284);
set(gca,'XTicklabel',{'0','\pi/4','\pi/2','3\pi/4','\pi','5\pi/4','3\pi/2','7\pi/4','2\pi'});
% set(gca,'YTick',1:0.01:1.05);   %1
% set(gca,'YTick',1:0.0006:1.003);   %2
% set(gca,'YTicklabel',{'1','1.0006','1.0012','1.0018','1.0024','1.003'});
% set(gca,'YTicklabel',{'1','1.004','1.008','1.012','1.018','1.02'});
set(gca,'YTick',1:0.0003:1.0015); %3
set(gca,'YTicklabel',{'1','1.0003','1.0006','1.0009','1.0012','1.0015'});
% set(gca,'YTick',1:0.0004:1.002); %4
% set(gca,'YTicklabel',{'1','1.0004','1.0008','1.0012','1.0016','1.002'});
% set(gca,'xgrid','on');
% set(gca,'ygrid','on');
set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
set(gca,'Linewidth',1.5,'GridAlpha',1);
% ll = legend('case 1','case 2');
legend('Case 1','Case 2','Case 3','Case 4','Location','northwest');
set(gca,'FontSize',15);

